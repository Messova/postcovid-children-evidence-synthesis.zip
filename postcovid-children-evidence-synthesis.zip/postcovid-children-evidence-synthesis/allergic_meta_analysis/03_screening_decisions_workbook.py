import pandas as pd, re
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
u=pd.read_pickle('unique.pkl'); c=pd.read_pickle('cand.pkl')
u['found_in']=(u.source+';'+u.get('also_in','').fillna('').astype(str)).str.replace('nan;','').str.replace(';nan','').str.strip(';')
u['found_in']=u.found_in.apply(lambda s:'; '.join(sorted(set([x for x in s.split(';') if x and x!='nan']))))
INC={6:'Children 1–16 y; PCR+ vs PCR− controls; incident asthma; HR reported',
 406:'Children 5–18 y; PCR+ vs PCR− (TriNetX); incident asthma; HR reported',
 858:'Children <18 y; COVID vs non-COVID (TriNetX US); incident AD, AR, asthma; prior allergy excluded',
 225:'Ages 1–64 with separate paediatric subanalysis; incident AD, asthma, rhinoconjunctivitis, urticaria'}
FT={7:'All-age claims cohorts (mean age 50); need age-stratified (<20 y) HRs from full text/supplement',
 133:'Korean NHIS all-age; age subgroup analysis reported — check paediatric stratum',
 21:'US EHR (≈118 M) all-age; check paediatric stratum for asthma/AR/AD',
 44:'TriNetX all-age, stratified by age — check paediatric stratum; overlaps with other TriNetX studies',
 451:'Korean nationwide all-age; chronic urticaria — check paediatric data',
 2007:'Korea/Japan binational; chronic urticaria — no abstract in export, check age strata',
 382:'Single tertiary centre, test-negative controls; AD — check age range/paediatric data',
 1609:'German claims data (letter), AD after COVID — likely includes children; check full text'}
EXM={1203:'Full text read: news digest; source = Kim & Choi, Allergol Select 2026 (KNHANES 2019 vs 2021) — cross-sectional pre/post-pandemic prevalence, no individual SARS-CoV-2 exposure or uninfected comparator',100:'Wrong comparator: infected with vs without pre-existing atopy (no uninfected controls)',
 74:'No uninfected control group (hospitalised children only)',
 887:'Adults only (UK Biobank 37–73 y)',466:'Adults only (UK Biobank)',387:'Adults; exposure = long COVID',
 661:'Mostly adults (median 61 y); no paediatric estimates for outcomes of interest',
 266:'≥12 y; 42-day window overlaps acute phase; outcomes not incident allergic disease ≥30 d',
 1693:'Exposure = maternal infection in pregnancy, not child infection (keep for discussion)',
 388:'Ecological/pandemic-period trend, no individual infection exposure',1049:'Ecological/pandemic-period trend',
 864:'Pandemic effect on hay fever treatment, not infection exposure',497:'No uninfected comparator; adults',
 2495:'No control group; adults',1304:'Correspondence (linked to included Yang 2025)',1486:'Comment (linked to Bar 2026)',
 3076:'Outcome = spirometry, not incident allergic diagnosis; URTI controls',3257:'Conference abstract without abstract text; no uninfected control indicated — verify',3157:'Case study',
 442:'Pre-existing AD/psoriasis; outcome = disease activity',270:'Adults with depression',26:'Pre-existing conditions as risk factors for PASC',961:'Not relevant design'}
def auto_reason(r):
    t=str(r.title).lower(); a=(t+' '+str(r.abstract).lower()); dt=str(r.doctype).lower()
    if re.search(r'review|editorial|letter|comment|erratum|correction|case report|chapter|short survey|news',dt) or re.search(r'case report|a case of|review|correspondence|reply to|corrigendum|correction',t):
        return 'Not an original cohort (review/editorial/letter/case report)'
    if not re.search(r'asthma|atopic dermatitis|eczema|allergic rhinitis|hay fever|rhinoconjunctivitis|urticaria|allergic disease|allergic disorder|atopic disease',a):
        return 'No allergic outcome of interest'
    if re.search(r'vaccin',t): return 'Exposure = vaccination, not infection'
    if re.search(r'pandemic|lockdown|restriction|social distancing|school closure',t): return 'Pandemic-period effect, not individual SARS-CoV-2 infection'
    return 'Allergic disease only as pre-existing condition/risk factor/exacerbation; not incident outcome vs uninfected controls'
rows=[]
for i,r in u.iterrows():
    if i in INC: d,why,m='Include – full text','Meets criteria on abstract: '+INC[i],'Manual'
    elif i in FT: d,why,m='Full text – check paediatric data','Potentially eligible: '+FT[i],'Manual'
    elif i in EXM: d,why,m='Exclude',EXM[i],'Manual'
    elif i in c.index: d,why,m='Exclude',auto_reason(r),'Manual (title/abstract)'
    else: d,why,m='Exclude',auto_reason(r),'Rule-based – verify'
    rows.append([i,r.title,str(r.authors)[:120],r.year,r.journal,r.doi,r.pmid,r.found_in,d,why,m,str(r.abstract)[:3000]])
S=pd.DataFrame(rows,columns=['ID','Title','Authors','Year','Journal','DOI','PMID','Found in','Decision','Reason','Screening method','Abstract'])
order={'Include – full text':0,'Full text – check paediatric data':1,'Exclude':2}
S['o']=S.Decision.map(order); S=S.sort_values(['o','Year'],ascending=[True,False]).drop(columns='o')
print(S.Decision.value_counts()); print(S.Reason.value_counts().head(12))

wb=Workbook(); F='Arial'
hdr=Font(name=F,bold=True,color='FFFFFF'); hfill=PatternFill('solid',fgColor='1F4E78'); base=Font(name=F,size=10)
thin=Side(style='thin',color='BFBFBF')
def style_header(ws,ncol,row=1):
    for c_ in range(1,ncol+1):
        x=ws.cell(row=row,column=c_); x.font=hdr; x.fill=hfill; x.alignment=Alignment(wrap_text=True,vertical='center')
# PRISMA
p=wb.active; p.title='PRISMA'
p['A1']='PRISMA 2020 flow – counts'; p['A1'].font=Font(name=F,bold=True,size=13)
data=[('Records identified – PubMed',1061,'From uploaded .nbib'),('Records identified – Scopus',1773,'From uploaded .csv'),
('Records identified – Web of Science',744,'From uploaded savedrecs (6).xls — full export'),
('Total identified','=SUM(B3:B5)',''),('Duplicates removed','=B6-B8','DOI → PMID → normalised title matching'),
('Records screened (title/abstract)',"=COUNTA(Screening!A:A)-1",''),
('Excluded at title/abstract','=COUNTIF(Screening!I:I,"Exclude")',''),
('Reports sought for full text','=B8-B9',''),
('  of which: likely include','=COUNTIF(Screening!I:I,"Include – full text")',''),
('  of which: check paediatric data','=COUNTIF(Screening!I:I,"Full text – check paediatric data")','')]
p.append([]); 
for j,(a,b,cm) in enumerate(data,start=3):
    p.cell(row=j,column=1,value=a).font=base; p.cell(row=j,column=2,value=b).font=base; p.cell(row=j,column=3,value=cm).font=Font(name=F,size=9,italic=True)
p['B5'].font=Font(name=F,size=10,color='0000FF'); p['B3'].font=Font(name=F,size=10,color='0000FF'); p['B4'].font=Font(name=F,size=10,color='0000FF')
p.column_dimensions['A'].width=42; p.column_dimensions['B'].width=12; p.column_dimensions['C'].width=70
p['A15']='Note: title/abstract screening was performed by an AI assistant (rule-based pre-filter + manual reading of 309 candidate records + 54 new WoS records with outcome terms). PRISMA requires two independent human reviewers — use this as reviewer 1 or as a pre-screen.'
p['A15'].font=Font(name=F,size=9,italic=True,color='C00000'); p['A15'].alignment=Alignment(wrap_text=True); p.merge_cells('A15:C17')
# Characteristics
ch=wb.create_sheet('Characteristics')
cols=['Study (first author, year)','Journal','DOI','Status','Country / data source','Design','Study period','Age of children','N infected / N controls','Infection ascertainment','Comparator','Outcomes (incident)','Follow-up','Effect estimates (from abstract)','Adjustment / matching','Look-back for prior disease','Overlap / notes']
ch.append(cols); style_header(ch,len(cols))
TF='Из полного текста'
chars=[
['Senter 2024','Pediatrics','10.1542/peds.2023-064615','Include','USA / Children\'s Hospital of Philadelphia care network (EHR)','Retrospective cohort','03/2020–02/2021 testing','1–16 y',TF,'SARS-CoV-2 PCR','PCR-negative children','Asthma','18 months','Asthma HR 0.96 (P=0.79), adjusted','Multivariable Cox: demographics, SES, atopic comorbidities',TF,'Test-negative design; pre-Omicron'],
['Yang 2025','Infection','10.1007/s15010-024-02329-3','Include','Global / TriNetX','Retrospective cohort, PSM','01/2021–12/2022','5–18 y',TF,'RT-PCR','PCR-negative children (stratified by vaccination)','Asthma','12 months','Unvaccinated: HR 2.26 (2.16–2.37); vaccinated: HR 2.75 (2.52–2.99)','Propensity score matching',TF,'TriNetX — overlaps with Yong 2025 and Chuang 2024; pick one per outcome'],
['Yong 2025','Asia Pacific Allergy','10.5415/apallergy.0000000000000245','Include','USA / TriNetX US Collaborative Network (56 facilities)','Retrospective cohort, 1:1 PSM','2020–2022','<18 y','412,017 / 412,017','ICD-10 U07.1 + RNA positivity','Non-COVID children with PCR testing','AD, AR, asthma (composite + each)','12 months','Any allergic: HR 1.21 (1.19–1.24); AD 1.18 (1.14–1.22); asthma 1.25 (1.22–1.29); AR 1.22 (1.19–1.26)','PSM 1:1','Prior allergic disease excluded','TriNetX overlap with Yang 2025'],
['Clarion 2026','Ann Allergy Asthma Immunol','10.1016/j.anai.2026.05.022','Include','USA / Military Health System (TRICARE)','Retrospective cohort, 1:2 PSM',TF,'1–64 y; paediatric subanalysis',TF,TF,'Uninfected matched beneficiaries','AD, asthma, rhinoconjunctivitis, urticaria (+ food, drug allergy)','18 months','Children: all except food allergy significant — extract paediatric HRs','PSM 1:2',TF,'Need paediatric-specific HRs'],
['Oh 2024','Nature Communications','10.1038/s41467-024-47176-w','Check','South Korea (K-CoV-N), Japan (JMDC), UK Biobank','Cohorts, 1:5 PSM','2020–2021','All ages (mean 50 y)','147,824 infected (main cohort)','Claims diagnosis',"Uninfected matched",'Asthma, AR, AD, food allergy','>30 d, ≥6 mo','All ages: asthma HR 2.25 (1.80–2.83); AR 1.23; AD 1.15 (0.96–1.37)','PSM 1:5',TF,'Include only if <20 y stratum available; Korean NHIS overlap with Kim 2024'],
['Kim BG 2024','J Allergy Clin Immunol Pract','10.1016/j.jaip.2023.09.015','Check','South Korea / NHIS claims','Retrospective cohort, matched',TF,'All ages; age subgroups',TF,'Claims diagnosis','Matched uninfected','Asthma',TF,'All ages: aHR 2.14 (1.88–2.45)','Matching + adjustment',TF,'Korean NHIS overlap'],
['Olbrich 2026','J Allergy Clin Immunol','10.1016/j.jaci.2025.07.030','Check','USA / EHR network (>118 M; likely TriNetX)','Retrospective matched cohort, PSM',TF,'All ages',"973,794 infected / 4,388,409 controls",'EHR',"Unexposed controls",'Asthma, AR, CRS, AD, EoE','3 months','All ages: asthma HR 1.66; AR 1.27; AD n.s.','PSM',TF,'Short follow-up; TriNetX overlap'],
['Chuang 2024','BMC Medicine','10.1186/s12916-024-03589-4','Check','USA / TriNetX','Retrospective cohort, PSM','01/2022–01/2024 (Omicron)','All ages; age-stratified','274,803 / 274,803',TF,'No-COVID matched','Asthma (also COPD, bronchiectasis)',TF,'All ages: asthma aHR 1.27 (1.22–1.33)','PSM',TF,'Vaccinated population; TriNetX overlap'],
['Kim MH 2025','J Dermatol','10.1111/1346-8138.17600','Check','South Korea / nationwide','Matched cohort 1:1',TF,'All ages','4,976,589 / 4,976,589','RT-PCR','Random matched uninfected','Chronic urticaria (+ vitiligo, AA, HZ)',TF,'CU increased (numbers from full text)','Multivariable Cox',TF,'Korean overlap with Lee 2024'],
['Lee S 2024','J Allergy Clin Immunol Pract','10.1016/j.jaip.2024.05.044','Check','South Korea + Japan','Binational cohorts',TF,TF,TF,TF,TF,'Chronic urticaria',TF,TF,TF,TF,'No abstract in export'],
['Bar 2026','Clin Exp Dermatol','10.1093/ced/llag054','Check','Israel? / single tertiary centre EHR','Cohort','03/2020–05/2023',TF,'22,368 / 181,873','Confirmed COVID','Test-negative controls','AD (+15 dermatoses)',TF,'AD IRR 1.35 (1.25–1.46), all ages','—',TF,'Check paediatric patients present'],
['Schmitt 2024','Allergy','10.1111/all.15827','Check','Germany / statutory health insurance claims (likely)','Cohort (letter)',TF,'Likely children + adults',TF,TF,TF,'AD',TF,TF,TF,TF,'Research letter; no abstract in export'],
]
for r in chars: ch.append(r)
for row in ch.iter_rows(min_row=2):
    for x in row: x.font=base; x.alignment=Alignment(wrap_text=True,vertical='top'); x.border=Border(top=thin,bottom=thin,left=thin,right=thin)
    st=row[3].value
    fill=PatternFill('solid',fgColor='E2EFDA' if st=='Include' else 'FFF2CC')
    for x in row: x.fill=fill
widths=[20,20,24,9,26,20,16,16,18,18,20,24,12,34,22,18,30]
for j,w in enumerate(widths,1): ch.column_dimensions[get_column_letter(j)].width=w
ch.freeze_panes='B2'
n=len(chars)+3
ch.cell(row=n,column=1,value='Legend: green = eligible on abstract; yellow = eligibility depends on paediatric data in full text. "Из полного текста" = to be extracted by reviewer. Effect estimates are copied from abstracts and must be verified against full text.').font=Font(name=F,size=9,italic=True)
# Screening
sc=wb.create_sheet('Screening')
sc.append(list(S.columns)); style_header(sc,len(S.columns))
for r in S.itertuples(index=False): sc.append([str(v) if v is not None else '' for v in r])
fills={'Include – full text':'E2EFDA','Full text – check paediatric data':'FFF2CC'}
for row in sc.iter_rows(min_row=2):
    for x in row: x.font=base
    f=fills.get(row[8].value)
    if f:
        for x in row[:11]: x.fill=PatternFill('solid',fgColor=f)
for j,w in enumerate([7,60,30,6,28,26,10,18,26,55,18,80],1): sc.column_dimensions[get_column_letter(j)].width=w
sc.freeze_panes='C2'; sc.auto_filter.ref=sc.dimensions
wb.move_sheet('Characteristics',offset=-1)
wb.save('outputs/allergic_postcovid_screening.xlsx')
