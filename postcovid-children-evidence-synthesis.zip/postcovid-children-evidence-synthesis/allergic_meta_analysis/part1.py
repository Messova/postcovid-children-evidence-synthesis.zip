import pandas as pd, re
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
u=pd.read_pickle('unique.pkl'); c=pd.read_pickle('cand.pkl')
u['found_in']=(u.source+';'+u.get('also_in','').fillna('').astype(str)).str.replace('nan;','').str.replace(';nan','').str.strip(';')
u['found_in']=u.found_in.apply(lambda s:'; '.join(sorted(set([x for x in s.split(';') if x and x!='nan']))))
INC={6:'Children 1–16 y; PCR+ vs PCR− controls; incident asthma; HR reported',
 406:'Children 5–18 y; PCR+ vs PCR− (TriNetX); incident asthma; HR reported',
 858:'Children <18 y; COVID vs non-COVID (TriNetX US); incident AD, AR, asthma; prior allergy excluded',
 225:'Ages 1–64 with separate paediatric subanalysis; incident AD, asthma, rhinoconjunctivitis, urticaria'}
FT={7:'All-age claims cohorts (mean age 50); need age-stratified (<20 y) HRs from full text/supplement',
 133:'Korean NHIS all-age; age subgroup analysis reported — check paediatric stratum',
 21:'US EHR (≈118 M) all-age; check paediatric stratum for asthma/AR/AD',
 44:'TriNetX all-age, stratified by age — check paediatric stratum; overlaps with other TriNetX studies',
 451:'Korean nationwide all-age; chronic urticaria — check paediatric data',
 2007:'Korea/Japan binational; chronic urticaria — no abstract in export, check age strata',
 382:'Single tertiary centre, test-negative controls; AD — check age range/paediatric data',
 1609:'German claims data (letter), AD after COVID — likely includes children; check full text'}
EXM={1203:'Full text read: news digest; source = Kim & Choi, Allergol Select 2026 (KNHANES 2019 vs 2021) — cross-sectional pre/post-pandemic prevalence, no individual SARS-CoV-2 exposure or uninfected comparator',100:'Wrong comparator: infected with vs without pre-existing atopy (no uninfected controls)',
 74:'No uninfected control group (hospitalised children only)',
 887:'Adults only (UK Biobank 37–73 y)',466:'Adults only (UK Biobank)',387:'Adults; exposure = long COVID',
 661:'Mostly adults (median 61 y); no paediatric estimates for outcomes of interest',
 266:'≥12 y; 42-day window overlaps acute phase; outcomes not incident allergic disease ≥30 d',
 1693:'Exposure = maternal infection in pregnancy, not child infection (keep for discussion)',
 388:'Ecological/pandemic-period trend, no individual infection exposure',1049:'Ecological/pandemic-period trend',
 864:'Pandemic effect on hay fever treatment, not infection exposure',497:'No uninfected comparator; adults',
 2495:'No control group; adults',1304:'Correspondence (linked to included Yang 2025)',1486:'Comment (linked to Bar 2026)',
 3076:'Outcome = spirometry, not incident allergic diagnosis; URTI controls',3257:'Conference abstract without abstract text; no uninfected control indicated — verify',3157:'Case study',
 442:'Pre-existing AD/psoriasis; outcome = disease activity',270:'Adults with depression',26:'Pre-existing conditions as risk factors for PASC',961:'Not relevant design'}
def auto_reason(r):
    t=str(r.title).lower(); a=(t+' '+str(r.abstract).lower()); dt=str(r.doctype).lower()
    if re.search(r'review|editorial|letter|comment|erratum|correction|case report|chapter|short survey|news',dt) or re.search(r'case report|a case of|review|correspondence|reply to|corrigendum|correction',t):
        return 'Not an original cohort (review/editorial/letter/case report)'
    if not re.search(r'asthma|atopic dermatitis|eczema|allergic rhinitis|hay fever|rhinoconjunctivitis|urticaria|allergic disease|allergic disorder|atopic disease',a):
        return 'No allergic outcome of interest'
    if re.search(r'vaccin',t): return 'Exposure = vaccination, not infection'
    if re.search(r'pandemic|lockdown|restriction|social distancing|school closure',t): return 'Pandemic-period effect, not individual SARS-CoV-2 infection'
    return 'Allergic disease only as pre-existing condition/risk factor/exacerbation; not incident outcome vs uninfected controls'
rows=[]
for i,r in u.iterrows():
    if i in INC: d,why,m='Include – full text','Meets criteria on abstract: '+INC[i],'Manual'
    elif i in FT: d,why,m='Full text – check paediatric data','Potentially eligible: '+FT[i],'Manual'
    elif i in EXM: d,why,m='Exclude',EXM[i],'Manual'
    elif i in c.index: d,why,m='Exclude',auto_reason(r),'Manual (title/abstract)'
    else: d,why,m='Exclude',auto_reason(r),'Rule-based – verify'
    rows.append([i,r.title,str(r.authors)[:120],r.year,r.journal,r.doi,r.pmid,r.found_in,d,why,m,str(r.abstract)[:3000]])
S=pd.DataFrame(rows,columns=['ID','Title','Authors','Year','Journal','DOI','PMID','Found in','Decision','Reason','Screening method','Abstract'])
order={'Include – full text':0,'Full text – check paediatric data':1,'Exclude':2}
S['o']=S.Decision.map(order); S=S.sort_values(['o','Year'],ascending=[True,False]).drop(columns='o')
print(S.Decision.value_counts()); print(S.Reason.value_counts().head(12))

wb=Workbook(); F='Arial'
hdr=Font(name=F,bold=True,color='FFFFFF'); hfill=PatternFill('solid',fgColor='1F4E78'); base=Font(name=F,size=10)
thin=Side(style='thin',color='BFBFBF')
def style_header(ws,ncol,row=1):
    for c_ in range(1,ncol+1):
        x=ws.cell(row=row,column=c_); x.font=hdr; x.fill=hfill; x.alignment=Alignment(wrap_text=True,vertical='center')
