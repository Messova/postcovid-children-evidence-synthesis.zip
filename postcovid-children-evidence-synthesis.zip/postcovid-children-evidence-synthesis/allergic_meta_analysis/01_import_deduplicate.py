import pandas as pd, re, glob, os
U='data/raw/'
# PubMed nbib
txt=open(glob.glob(U+'*.nbib')[0],encoding='utf-8',errors='ignore').read().replace('\r','')
recs=[]
for block in re.split(r'\n\s*\n(?=PMID-)',txt.strip()):
    d={};key=None
    for line in block.split('\n'):
        m=re.match(r'^([A-Z]{2,4})\s*- (.*)$',line)
        if m:
            key=m.group(1); d.setdefault(key,[]).append(m.group(2))
        elif key and line.startswith('      '):
            d[key][-1]+=' '+line.strip()
    doi=''
    for l in d.get('LID',[])+d.get('AID',[]):
        if '[doi]' in l: doi=l.replace('[doi]','').strip();break
    recs.append(dict(source='PubMed',title=' '.join(d.get('TI',[''])),abstract=' '.join(d.get('AB',[''])),
        year=(d.get('DP',[''])[0][:4]),doi=doi,pmid=d.get('PMID',[''])[0].strip(),
        authors='; '.join(d.get('AU',[])),journal=d.get('JT',[''])[0],doctype='; '.join(d.get('PT',[]))))
pm=pd.DataFrame(recs)
s=pd.read_csv(glob.glob(U+'export*.csv')[0])
sc=pd.DataFrame(dict(source='Scopus',title=s['Title'],abstract=s['Abstract'],year=s['Year'].astype(str),doi=s['DOI'],pmid='',
    authors=s['Authors'],journal=s['Source title'],doctype=s['Document Type']))
w=pd.read_excel(U+'savedrecs__6_.xls',engine='xlrd')
wo=pd.DataFrame(dict(source='WoS',title=w['Article Title'],abstract=w['Abstract'],year=w['Publication Year'].astype(str),doi=w['DOI'],
    pmid=w['Pubmed Id'].fillna('').astype(str).str.replace(r'\.0$','',regex=True),authors=w['Authors'],journal=w['Source Title'],doctype=w['Document Type']))
all_=pd.concat([pm,sc,wo],ignore_index=True).fillna('')
print(all_.source.value_counts())
def nt(t): return re.sub(r'[^a-z0-9]','',str(t).lower())[:120]
all_['doi_n']=all_.doi.str.lower().str.strip().str.replace(r'^https?://(dx\.)?doi\.org/','',regex=True)
all_['tn']=all_.title.map(nt)
# priority PubMed>Scopus>WoS already in order
keep=[];seen_doi={};seen_t={};seen_p={};dups=[]
for i,r in all_.iterrows():
    k=None
    if r.doi_n and r.doi_n in seen_doi: k=seen_doi[r.doi_n]
    elif r.pmid and r.pmid in seen_p: k=seen_p[r.pmid]
    elif r.tn and len(r.tn)>20 and r.tn in seen_t: k=seen_t[r.tn]
    if k is not None:
        dups.append(i); all_.at[k,'source']  # noop
        all_.loc[k,'also_in']=(str(all_.loc[k].get('also_in','')) + ';'+r.source).strip(';')
        if not all_.loc[k,'abstract'] and r.abstract: all_.loc[k,'abstract']=r.abstract
        continue
    keep.append(i)
    if r.doi_n: seen_doi[r.doi_n]=i
    if r.pmid: seen_p[r.pmid]=i
    if r.tn: seen_t[r.tn]=i
u=all_.loc[keep].copy()
print('total',len(all_),'dups',len(dups),'unique',len(u))
u.to_pickle('unique.pkl'); all_.to_pickle('all.pkl')
