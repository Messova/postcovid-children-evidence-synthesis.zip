import pandas as pd,re
u=pd.read_pickle('unique.pkl')
T=u.title.str.lower(); A=(u.title+' '+u.abstract).str.lower()
out=r'asthma|atopic dermatitis|eczema|allergic rhinitis|hay fever|rhinoconjunctivitis|urticaria|allergic disease|allergic disorder|atopic disease|allergic condition|allerg'
inc=r'incident|new[- ]onset|newly diagnosed|de novo|post[- ]acute|sequela|long[- ]term|subsequent|following sars|after sars|after covid|following covid|post[- ]covid|long covid|pasc|risk of develop|hazard ratio'
child=r'child|pediatric|paediatric|adolescen|infant|youth|teen|kids|school|young people|minor|under 18|aged 0|0-17|0–17|0-18|<18'
u['out_t']=T.str.contains(out); u['out_a']=A.str.contains(out); u['inc']=A.str.contains(inc); u['child']=A.str.contains(child)
# review types
u['rev']=u.doctype.str.lower().str.contains('review|editorial|letter|comment|erratum|note|case report|chapter|short survey')&~u.doctype.str.lower().str.contains('journal article; review')|u.doctype.str.lower().str.contains('review')
cand=u[(u.out_a)&(u.inc)&(u.title.str.lower().str.contains(out)|u.abstract.str.lower().str.contains(r'incident|new[- ]onset|newly diagnosed|de novo|hazard ratio'))]
print(len(u), u.out_a.sum(), (u.out_a&u.inc).sum(), len(cand))
cand.to_pickle('cand.pkl')
