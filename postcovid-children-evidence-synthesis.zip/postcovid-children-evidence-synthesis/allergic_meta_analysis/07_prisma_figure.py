import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
fig,ax=plt.subplots(figsize=(11,12.5)); ax.set_xlim(0,110); ax.set_ylim(0,125); ax.axis('off')
plt.rcParams['font.family']='DejaVu Sans'
def box(x,y,w,h,t,fc='white',fs=9,bold=False):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.3,rounding_size=0.8',fc=fc,ec='black',lw=1))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,wrap=True,fontweight='bold' if bold else 'normal')
def arr(x1,y1,x2,y2): ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle='->',lw=1))
H='#DCE6F1'
box(2,112,70,8,'Identification of studies via databases and registers',fc=H,fs=10,bold=True)
box(78,112,30,8,'Identification of studies\nvia other methods',fc=H,fs=10,bold=True)
# side labels
for y,t in [(95,'Identification'),(62,'Screening'),(12,'Included')]:
    ax.text(-1,y,t,rotation=90,va='center',ha='center',fontsize=10,fontweight='bold')
box(2,88,32,18,'Records identified from:\nPubMed (n = 1,061)\nScopus (n = 1,773)\nWeb of Science (n = 744)\nTotal (n = 3,578)')
box(40,91,32,12,'Records removed before\nscreening:\nDuplicate records (n = 1,294)')
arr(34.3,97,39.7,97)
box(2,70,32,10,'Records screened\n(n = 2,284)'); arr(18,87.7,18,80.3)
box(40,70,32,10,'Records excluded\n(n = 2,272)'); arr(34.3,75,39.7,75)
box(2,54,32,10,'Reports sought for retrieval\n(n = 12)'); arr(18,69.7,18,64.3)
box(40,54,32,10,'Reports not retrieved\n(n = 1)'); arr(34.3,59,39.7,59)
box(2,38,32,10,'Reports assessed for eligibility\n(n = 11)'); arr(18,53.7,18,48.3)
box(40,32,32,19,'Reports excluded (n = 6):\nAdults only, ≥18/≥20 years\n(n = 4)\nNo separate paediatric\nestimate (n = 2)',fs=8.5); arr(34.3,43,39.7,43)
box(78,88,30,18,'Records identified from:\nCitation searching (n = 1)')
box(78,54,30,10,'Reports sought for retrieval\n(n = 1)'); arr(93,87.7,93,64.3)
box(78,38,30,10,'Reports assessed for eligibility\n(n = 1)'); arr(93,53.7,93,48.3)
box(78,20,30,12,'Reports excluded (n = 1):\nNo outcome of interest',fs=8.5); arr(93,37.7,93,32.3)
box(2,3,32,17,'Studies included in review\n(n = 5 reports;\n4 independent cohorts)\n\nIncluded in meta-analysis:\nasthma k = 3, AD k = 3,\nAR k = 2; urticaria k = 1\n(narrative only)',fs=8.5); arr(18,37.7,18,20.3)
ax.text(40,8,'Yang 2025 and Yong 2025 draw on the same TriNetX US\nnetwork and overlapping period; Yang 2025 is used\nin sensitivity analysis only.',fontsize=7.5,style='italic',va='center')
plt.savefig('/mnt/user-data/outputs/PRISMA_flow_allergic_postcovid.png',dpi=300,bbox_inches='tight')
plt.savefig('/mnt/user-data/outputs/PRISMA_flow_allergic_postcovid.svg',bbox_inches='tight')
