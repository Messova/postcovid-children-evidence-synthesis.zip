# Meta-analysis: new-onset allergic diseases after SARS-CoV-2 infection in children
# Random-effects (REML) with Hartung-Knapp-Sidik-Jonkman adjustment (metafor)
library(metafor)
set_dir <- "."

z95  <- qnorm(0.975)
zbon <- qnorm(1 - 0.05/6/2)   # Clarion 2026: Bonferroni-corrected CIs (alpha = 0.05/6)

se_from_ci <- function(lo, hi, z) (log(hi) - log(lo)) / (2 * z)

dat <- data.frame(
  outcome = c("Asthma","Asthma","Asthma","Asthma",
              "Atopic dermatitis","Atopic dermatitis","Atopic dermatitis",
              "Allergic rhinitis","Allergic rhinitis","Urticaria"),
  study   = c("Senter 2024","Yong 2025","Clarion 2026","Yang 2025",
              "Yong 2025","Clarion 2026","Schmitt 2024",
              "Yong 2025","Clarion 2026","Clarion 2026"),
  est = c(0.96, 1.252, 1.82, 2.26,  1.179, 1.15, 14.59/10.70,  1.223, 1.38,  1.20),
  lo  = c(0.73, 1.216, 1.38, 2.158, 1.140, 1.004, NA,          1.188, 1.27,  1.03),
  hi  = c(1.27, 1.290, 2.41, 2.367, 1.219, 1.31,  NA,          1.259, 1.50,  1.40),
  z   = c(z95, z95, zbon, z95, z95, zbon, NA, z95, zbon, zbon),
  comparator = c("Test-negative, multivariable","Test-negative, PSM","Uninfected, PSM","Test-negative, PSM",
                 "Test-negative, PSM","Uninfected, PSM","Uninfected, matched",
                 "Test-negative, PSM","Uninfected, PSM","Uninfected, PSM"),
  rob = c("Some concerns","High","Some concerns","High","High","Some concerns","Some concerns",
          "High","Some concerns","Some concerns"),
  main = c(TRUE, TRUE, TRUE, FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE),
  stringsAsFactors = FALSE)

dat$yi  <- log(dat$est)
dat$sei <- se_from_ci(dat$lo, dat$hi, dat$z)
# Schmitt 2024 (<18 y): SE from events (622 vs 456 weighted control events)
dat$sei[dat$study == "Schmitt 2024"] <- sqrt(1/622 + 1/456)

res_row <- function(fit, label, outcome) {
  data.frame(outcome = outcome, analysis = label, k = fit$k,
             pooled = round(exp(fit$b[1]), 3),
             ci_lb = round(exp(fit$ci.lb), 3), ci_ub = round(exp(fit$ci.ub), 3),
             p = signif(fit$pval, 3), tau2 = round(fit$tau2, 4),
             I2 = round(fit$I2, 1),
             pi_lb = if (fit$k >= 3) round(exp(predict(fit)$pi.lb), 3) else NA,
             pi_ub = if (fit$k >= 3) round(exp(predict(fit)$pi.ub), 3) else NA)
}
fit_re <- function(d, test = "knha", method = "REML")
  rma(yi = yi, sei = sei, data = d, method = method, test = test, slab = study)

out <- list()
for (o in c("Asthma","Atopic dermatitis","Allergic rhinitis")) {
  d  <- subset(dat, outcome == o & main)
  f1 <- fit_re(d);                    out[[length(out)+1]] <- res_row(f1, "Main: REML + HKSJ", o)
  f2 <- fit_re(d, test = "z");        out[[length(out)+1]] <- res_row(f2, "Sensitivity: REML, Wald CI", o)
  dl <- subset(d, rob != "High")
  if (nrow(dl) >= 2) { f3 <- fit_re(dl); out[[length(out)+1]] <- res_row(f3, "Sensitivity: excluding high RoB (Yong 2025)", o) }
  if (o == "Asthma") {
    dy <- subset(dat, outcome == o & study != "Yong 2025")
    f4 <- fit_re(dy); out[[length(out)+1]] <- res_row(f4, "Sensitivity: Yang 2025 instead of Yong 2025", o)
  }
  if (nrow(d) >= 3) {
    l1 <- leave1out(f1, transf = exp)
    write.csv(data.frame(omitted = d$study, pooled = round(l1$estimate,3),
                         ci_lb = round(l1$ci.lb,3), ci_ub = round(l1$ci.ub,3), I2 = round(l1$I2,1)),
              file.path(set_dir, paste0("leave1out_", gsub(" ", "_", o), ".csv")), row.names = FALSE)
  }
  png(file.path(set_dir, paste0("forest_", gsub(" ", "_", o), ".png")),
      width = 2400, height = 300 + 220 * nrow(d), res = 300)
  forest(f1, atransf = exp, at = log(c(0.5, 1, 2, 4)), xlim = c(-4.5, 3.2),
         ilab = d$comparator, ilab.xpos = -2.3, ilab.pos = 4, cex = 0.75,
         header = c("Study", "HR/IRR [95% CI]"), refline = 0,
         mlab = sprintf("RE (REML, HKSJ): I\u00b2 = %.0f%%", f1$I2),
         xlab = "Hazard / incidence rate ratio (log scale)")
  text(-2.3, f1$k + 2, "Comparator / design", pos = 4, cex = 0.75, font = 2)
  mtext(o, side = 3, line = 0.5, cex = 0.9, font = 2)
  dev.off()
}
results <- do.call(rbind, out)
write.csv(results, file.path(set_dir, "meta_results.csv"), row.names = FALSE)
write.csv(transform(dat, se = round(sei, 4), yi = round(yi, 4)), file.path(set_dir, "input_data.csv"), row.names = FALSE)
print(results)
cat("\nUrticaria: single study (Clarion 2026, HR 1.20, Bonferroni CI 1.03-1.40) - narrative synthesis only.\n")
