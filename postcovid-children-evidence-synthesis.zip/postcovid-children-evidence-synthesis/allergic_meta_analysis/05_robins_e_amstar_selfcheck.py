exec(open('04_fulltext_characteristics_effectsizes.py').read().replace("wb.save('outputs/allergic_postcovid_screening.xlsx')",""))
L=PatternFill('solid',fgColor='C6EFCE'); S_=PatternFill('solid',fgColor='FFEB9C'); Hh=PatternFill('solid',fgColor='FFC7CE')
rb=wb.create_sheet('ROBINS-E',2)
head(rb,['Study','D1 Confounding','D2 Exposure measurement','D3 Selection of participants','D4 Post-exposure interventions','D5 Missing data','D6 Outcome measurement','D7 Selection of reported result','Overall','Key reasons'])
RB=[
['Senter 2024','Some concerns','Some concerns','Some concerns','Low','Low','Some concerns','Low','Some concerns','Multivariable adjustment incl. SES and atopy but no utilisation intensity; test-negative controls may acquire infection later (non-differential, toward null); inclusion required a follow-up visit; asthma = ICD + medication (good), single visit'],
['Yong 2025','High','Some concerns','Some concerns','Low','Some concerns','High','Some concerns','High','PSM on limited covariates (no family atopy, no utilisation intensity, vaccination not excluded in main analysis) → residual confounding and surveillance bias; single ICD code; AD definition includes contact dermatitis (L23–L25), asthma includes J44; missing data not reported'],
['Yang 2025','Some concerns','Some concerns','Some concerns','Low','Some concerns','Some concerns','High','High','PSM on broad covariates; asthma by ICD only, composite with death; implausible finding of higher risk in vaccinated children not explained; multiple outcomes/cohorts with selective emphasis'],
['Clarion 2026','Some concerns','Low','Low','Low','Low','Some concerns','Low','Some concerns','Monthly PSM on 1,852 past-year variables, exact matching on age/sex; equal access to care limits detection bias; controls censored at infection; 2-y washout; outcomes ICD-only; vaccination and family history not accounted for'],
['Schmitt 2024','Some concerns','Some concerns','Low','Low','Some concerns','Low','Some concerns','Some concerns','Matching on age, sex, autoimmunity, comorbidity PS only; 2020 exposure (possible undocumented infection in controls); AD requires ≥2 diagnoses (+ medication sensitivity); research letter — paediatric CI not reported'],
]
for r in RB: rb.append(r)
body(rb)
for row in rb.iter_rows(min_row=2):
    for x in row[1:9]: x.fill={'Low':L,'Some concerns':S_,'High':Hh}[x.value]; x.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
widths(rb,[14,14,14,14,14,12,14,14,13,70]); rb.freeze_panes='B2'
rb.cell(row=rb.max_row+2,column=1,value='Provisional judgements by an AI assistant from full texts; to be confirmed by two independent reviewers. Overall = worst domain judgement (ROBINS-E algorithm). Robvis traffic-light plot can be generated from this sheet.').font=Font(name=F,size=9,italic=True)
# AMSTAR 2 self-check
am=wb.create_sheet('AMSTAR 2 self-check',3)
head(am,['#','AMSTAR 2 item','Critical?','Current status of our review','Rating now','Action needed before submission'])
AM=[
[1,'PICO components in question and inclusion criteria','No','PICO defined (children 0–18 y, infected vs uninfected, incident asthma/AD/AR/urticaria, controlled cohorts)','Yes','—'],
[2,'Protocol established before conduct; deviations justified','YES','PROSPERO draft prepared but NOT registered; search, screening and extraction already done','No','Register now (OSF or PROSPERO if accepted) and state registration date honestly; report deviations (Embase dropped, preprints not searched)'],
[3,'Explanation of study designs included','No','Controlled cohorts only; rationale in protocol','Yes','State rationale in Methods'],
[4,'Comprehensive literature search','YES','PubMed, Scopus, WoS; reference/citation searching (1 record); no Embase, no preprints, no grey literature','Partial yes','Add forward citation search of included studies and medRxiv via Europe PMC; justify Embase omission'],
[5,'Study selection in duplicate','No','Single AI-assisted screening','No','Second human reviewer screens all included/excluded full texts and a sample of title/abstract exclusions; report agreement (kappa)'],
[6,'Data extraction in duplicate','No','Single AI-assisted extraction','No','Second reviewer verifies Characteristics and Effect sizes sheets'],
[7,'List of excluded studies with justification','YES','Full-text exclusions listed with reasons (Full-text sheet)','Yes','Include as supplementary table'],
[8,'Included studies described in adequate detail','No','Characteristics table complete','Yes','—'],
[9,'Satisfactory technique for assessing RoB','YES','ROBINS-E applied (provisional)','Yes (after 2nd reviewer)','Second reviewer confirms judgements'],
[10,'Sources of funding of included studies','No','Available in papers: Senter — NIH/CHOP; Yong — China Medical University Hospital; Yang — none; Clarion — USU intramural; Schmitt — German Ministry of Health','Yes','Add funding column to characteristics table'],
[11,'Appropriate meta-analytic methods','YES','Planned: random effects (REML) + Hartung-Knapp; lnHR/SE computed; Bonferroni CIs of Clarion converted; overlap handled','Yes (planned)','Run and report as planned'],
[12,'Impact of RoB on meta-analysis assessed','No','Planned','Pending','Sensitivity analysis excluding high-RoB studies (Yong; Yang already sensitivity only)'],
[13,'RoB accounted for when interpreting results','YES','Planned','Pending','Discuss surveillance bias and outcome definitions; GRADE downgrade'],
[14,'Explanation of heterogeneity','No','Expected high (Senter null vs others)','Pending','Discuss by comparator type (test-negative vs PSM), period, outcome definitions'],
[15,'Publication bias investigated','YES','k < 10 per outcome — funnel/Egger not informative','Pending','State that formal tests were not possible and discuss small-study/ publication bias qualitatively'],
[16,'Conflicts of interest and funding of the review','No','—','Pending','Declare in manuscript'],
]
for r in AM: am.append(r)
body(am)
for row in am.iter_rows(min_row=2):
    v=row[4].value
    f=L if v.startswith('Yes') else Hh if v=='No' else S_
    row[4].fill=f
    if row[2].value=='YES': row[2].font=Font(name=F,size=10,bold=True,color='C00000')
widths(am,[4,38,9,55,14,55]); am.freeze_panes='C2'
am.cell(row=am.max_row+2,column=1,value='Current overall confidence (Shea 2017 rules): CRITICALLY LOW — critical flaw on item 2 (no a-priori protocol), plus non-critical weaknesses (items 5, 6). After registration with honest dating, duplicate screening/extraction and completed analyses, achievable rating: LOW–MODERATE (item 2 remains a flaw because registration is retrospective).').font=Font(name=F,size=10,bold=True)
# funding column in characteristics
ch=wb['Characteristics']; c=ch.max_column+1
ch.cell(row=1,column=c,value='Funding'); ch.cell(row=1,column=c).font=hdr; ch.cell(row=1,column=c).fill=hfill
fund={'Senter 2024':'NIH (K23HL136842, R01 HL162715); CHOP Research Institute','Yong 2025':'China Medical University Hospital (DMR grants)','Yang 2025':'No external funding','Clarion 2026':'Uniformed Services University intramural award','Schmitt 2024':'German Federal Ministry of Health (ZMI1-2521NIK705)'}
for r in range(2,ch.max_row+1):
    k=ch.cell(row=r,column=1).value
    if k in fund:
        x=ch.cell(row=r,column=c,value=fund[k]); x.font=base; x.border=bd; x.alignment=Alignment(wrap_text=True,vertical='top'); x.fill=Y if k=='Yang 2025' else G
ch.column_dimensions[get_column_letter(c)].width=28
wb.save('outputs/allergic_postcovid_screening.xlsx')
