exec(open('part1.py').read())
wb=Workbook(); F='Arial'
hdr=Font(name=F,bold=True,color='FFFFFF'); hfill=PatternFill('solid',fgColor='1F4E78'); base=Font(name=F,size=10)
blue=Font(name=F,size=10,color='0000FF'); thin=Side(style='thin',color='BFBFBF'); bd=Border(top=thin,bottom=thin,left=thin,right=thin)
G=PatternFill('solid',fgColor='E2EFDA'); Y=PatternFill('solid',fgColor='FFF2CC'); R=PatternFill('solid',fgColor='F8CBAD')
def head(ws,cols):
    ws.append(cols)
    for x in ws[ws.max_row]: x.font=hdr; x.fill=hfill; x.alignment=Alignment(wrap_text=True,vertical='center')
def body(ws,r0=2):
    for row in ws.iter_rows(min_row=r0):
        for x in row:
            if x.font!=blue: x.font=base if x.font.color is None or x.font.color.rgb!='FF0000FF' else x.font
            x.alignment=Alignment(wrap_text=True,vertical='top'); x.border=bd
def widths(ws,ws_):
    for j,w in enumerate(ws_,1): ws.column_dimensions[get_column_letter(j)].width=w

# ---------- Full-text assessment ----------
ft=wb.active; ft.title='Full-text'
head(ft,['Study','DOI','Decision','Reason (full text)','Role in synthesis'])
FTROWS=[
['Senter 2024, Pediatrics','10.1542/peds.2023-064615','Include','Children 1–16 y; PCR+ vs PCR− (test-negative); incident asthma (ICD + asthma medication); 18-mo follow-up from day 30','Asthma'],
['Yong 2025, Asia Pac Allergy','10.5415/apallergy.0000000000000245','Include','Children <18 y; PCR+ vs PCR− (TriNetX US, 56 HCOs, 2020–2022); prior allergic disease excluded; AD, asthma, AR day 30–365','AD, asthma, AR (primary TriNetX estimate)'],
['Yang 2025, Infection','10.1007/s15010-024-02329-3','Include (overlapping data)','Children 5–18 y; PCR+ vs PCR− (TriNetX US, 64 HCOs, 2021–2022); asthma day 30–365; outcome composite with death','Asthma — sensitivity only (same TriNetX US network/period as Yong 2025)'],
['Clarion 2026, Ann Allergy Asthma Immunol','10.1016/j.anai.2026.05.022','Include','Separate paediatric subgroup 1–17 y (32,118 vs 64,236), US Military Health System; washout 730 d before to 30 d after index; outcomes day 31–548','AD, asthma, AR (rhinoconjunctivitis), urticaria'],
['Schmitt 2024, Allergy (letter)','10.1111/all.15827','Include','German statutory insurance claims; PCR-confirmed 2020, 1:3 matched; AD 3–15 mo; separate <18 y stratum (IR 14.59 vs 10.70/1000 PY)','AD'],
['Oh 2024, Nat Commun','10.1038/s41467-024-47176-w','Exclude','Wrong population: all three cohorts restricted to ≥20 years (authors state study limited to adults)','Discussion only'],
['Kim BG 2024, JACI Pract','10.1016/j.jaip.2023.09.015','Exclude','Wrong population: health-checkup cohort, asthma defined in those ≥18 y; mean age 50.8; youngest stratum ≤29 y','Discussion only'],
['Olbrich 2026, JACI','10.1016/j.jaci.2025.07.030','Exclude','Wrong population: only individuals ≥18 years (TriNetX US)','Discussion only'],
['Chuang 2024, BMC Med','10.1186/s12916-024-03589-4','Exclude','Wrong population: ≥18 years, vaccinated adults (TriNetX US)','Discussion only'],
['Kim MH 2025, J Dermatol','10.1111/1346-8138.17600','Exclude (or contact author)','All ages; youngest stratum <30 y; no paediatric-specific HR for chronic urticaria reported','Could be included if author provides <18 y estimate'],
['Bar 2026, Clin Exp Dermatol','10.1093/ced/llag054','Exclude (or contact author)','All ages (mean 46 y); no age-stratified estimates; outcome AD IRR 1.35 for whole cohort','Could be included if author provides <18 y estimate'],
['Roessler 2022, PLoS Med (citation searching)','10.1371/journal.pmed.1004122','Exclude (other methods)','No outcome of interest: 96 outcomes (S1 Appendix, Section C) include no asthma, AD, AR or urticaria; asthma used only as a matching covariate; dermatological complex = hair loss, rash, subcutaneous nodules','Not used; same German insurance data as Schmitt 2024'],
['Lee S 2024, JACI Pract','10.1016/j.jaip.2024.05.044','Awaiting full text','Chronic urticaria, Korea & Japan; full text not yet available (closed access)','Urticaria — pending'],
]
for r in FTROWS: ft.append(r)
body(ft)
for row in ft.iter_rows(min_row=2):
    f={'Include':G,'Include (overlapping data)':G,'Awaiting full text':Y}.get(row[2].value,R if row[2].value.startswith('Exclude') else None)
    if f:
        for x in row: x.fill=f
widths(ft,[30,30,22,70,40]); ft.freeze_panes='A2'

# ---------- Characteristics ----------
ch=wb.create_sheet('Characteristics')
cols=['Study','Country / data source','Design & matching','Exposure window','Age (paediatric sample)','N infected / N controls (paediatric)','Infection ascertainment','Comparator','Prior-disease exclusion','Outcomes & definitions','Outcome window','Adjustment','Effect estimates (paediatric)','Notes / risk-of-bias flags']
head(ch,cols)
CH=[
['Senter 2024','USA — Children\'s Hospital of Philadelphia Care Network (EHR, single system, 3 states)','Retrospective cohort; multivariable Cox (no matching)','03/2020–02/2021 (pre-Omicron, pre-vaccination)','1–16 y (28% 1–4, 40% 5–11, 32% ≥12 among PCR+)','3,147 / 24,276','SARS-CoV-2 PCR','PCR-negative children (test-negative); ≥1 well-child visit in prior year','Not explicitly stated in methods ("asthma-naïve" in conclusions) — verify','Asthma: ICD J45/493 + asthma medication; excl. "reactive airway"/"post-viral wheeze". Sensitivity: ≥2 visits ≥6 mo apart','Day 30 to 18 mo','Sex, age, race, insurance, Child Opportunity Index, gestational age, BMI, AD, food allergy, AR','Asthma HR 0.96 (0.73–1.27); strict definition HR 0.80 (0.56–1.13); 1–4 y 0.92 (0.64–1.31); 5–11 y 1.29 (0.78–2.08); ≥12 y 0.47 (0.17–1.31). Events 57 vs 516','Only study with null result; smallest; test-negative controls; adjusted for atopic comorbidities (possible over-adjustment)'],
['Yong 2025','USA — TriNetX US Collaborative Network (56 HCOs, EHR)','Retrospective cohort; 1:1 PSM (age, sex, race, ethnicity, utilisation, comorbidities); Cox','01/2020–12/2022 (all variants)','<18 y (mean 8.1 ± 6.2)','412,017 / 412,017','ICD-10 U07.1 + SARS-CoV-2 RNA positive','PCR-negative children, ≥2 visits','Yes — prior AD, asthma, AR excluded','AD: L20, L23–L25; asthma: J44–J45; AR: J30 (each combined with death)','Day 30 to 1 y','PSM only (no outcome-model adjustment)','AD HR 1.179 (1.140–1.219); asthma HR 1.252 (1.216–1.290); AR HR 1.223 (1.188–1.259); events AD 7,587 vs 6,365; asthma 9,937 vs 7,842; AR 10,224 vs 8,298','Broad AD definition incl. contact dermatitis (L23–L25); asthma incl. J44; vaccinated not excluded in main analysis (sensitivity consistent); overlaps with Yang 2025'],
['Yang 2025','USA — TriNetX US Collaborative Network (64 HCOs, EHR)','Retrospective cohort; 1:1 PSM; Cox; two cohorts by vaccination status','01/2021–12/2022','5–18 y (mean 11.7)','Unvaccinated 128,753 / 128,753; vaccinated 23,497 / 23,497','RT-PCR','PCR-negative children','Yes — prior asthma, prior COVID-19, neoplasm excluded','Asthma or death (ICD-10); secondary: anti-asthmatic drugs','Day 30 to 365','PSM only','Unvaccinated: HR 2.26 (2.158–2.367), events 6,026 vs 2,568; vaccinated: HR 2.745 (2.521–2.99), events 1,941 vs 726','Composite with death; same network and overlapping period as Yong 2025 → sensitivity analysis only'],
['Clarion 2026','USA — TRICARE Military Health System Data Repository (claims + labs)','Retrospective cohort; monthly 1:2 PSM on 1,852 past-year variables; exact match on age, sex, beneficiary status; conditional Cox stratified on matched sets','07/2020–06/2021 (pre-Omicron)','Paediatric subgroup 1–17 y (median 12)','32,118 / 64,236 (before outcome-specific washout)','ICD-10 (U07.1, J12.82, M35.81) or positive PCR/antigen','Matched TRICARE beneficiaries without COVID-19; censored if later infected','Yes — outcome-specific washout 730 d before to 30 d after index','AD, asthma, rhinoconjunctivitis, urticaria (+ food, drug allergy) by ICD-10-CM','Day 31 to 548','Sponsor rank','AD HR 1.15 (1.004–1.31); asthma 1.82 (1.38–2.41); rhinoconjunctivitis 1.38 (1.27–1.50); urticaria 1.20 (1.03–1.40). NB: CIs are Bonferroni-corrected (α = 0.0083). Events AD 648 vs 1,075; asthma 690 vs 1,025; rhinoconj. 1,836 vs 2,590; urticaria 485 vs 759','Military families (equal access to care); vaccination not accounted for; rhinoconjunctivitis used as AR proxy'],
['Schmitt 2024','Germany — statutory health insurance claims (several insurers)','Matched cohort 1:3 (age, sex, prior autoimmune disease, comorbidity PS); Poisson IRR','PCR-confirmed COVID-19 in 2020 (pre-vaccination)','<18 y stratum','Stratum N not reported (events 622 vs 456 weighted)','PCR','Matched insured persons without COVID-19','Yes — prevalent AD in 4 prior quarters excluded','AD: ≥2 physician diagnoses (L20; L30 for adults) ≤2 quarters apart or inpatient diagnosis; sensitivity with AD medication','3 to 15 mo','Matching only','<18 y: IR 14.59 vs 10.70 /1000 PY → IRR ≈ 1.36 (approx. 1.21–1.54, consistent with Fig. 1); with medication: 4.72 vs 3.38 → IRR ≈ 1.40','Research letter; paediatric CI not reported numerically — computed from IR/events; confirm with authors'],
]
for r in CH: ch.append(r)
body(ch)
for row in ch.iter_rows(min_row=2):
    for x in row: x.fill=Y if row[0].value=='Yang 2025' else G
widths(ch,[14,26,28,18,18,20,20,22,22,32,14,24,40,36]); ch.freeze_panes='B2'
n=ch.max_row+2
ch.cell(row=n,column=1,value='Green = included in main analyses; yellow = overlapping data (TriNetX US), used in sensitivity analysis only. All values extracted from full texts by an AI assistant — verify against the PDFs (second extractor).').font=Font(name=F,size=9,italic=True)

# ---------- Effect sizes ----------
es=wb.create_sheet('Effect sizes')
es['A1']='z for 95% CI'; es['B1']=1.959964; es['B1'].font=blue
es['A2']='z for Bonferroni CI (α = 0.05/6)'; es['B2']=2.638257; es['B2'].font=blue
es['D1']='Blue = inputs typed from papers; black = formulas. ln(HR) and SE feed any meta-analysis software (e.g. R metagen: TE = lnHR, seTE = SE).'
es['D1'].font=Font(name=F,size=9,italic=True)
head(es,['Outcome','Study','Measure','Estimate','Lower CI','Upper CI','CI type (z cell)','ln(estimate)','SE','Analysis set','Note'])
hr=es.max_row
ROWS=[
['Asthma','Senter 2024','HR (adjusted)',0.96,0.73,1.27,'$B$1','Main',''],
['Asthma','Yong 2025','HR (PSM)',1.252,1.216,1.290,'$B$1','Main','TriNetX estimate chosen for main analysis'],
['Asthma','Clarion 2026 (1–17 y)','HR (PSM, adj.)',1.82,1.38,2.41,'$B$2','Main','Bonferroni-corrected CI in paper'],
['Asthma','Yang 2025 (unvaccinated)','HR (PSM)',2.26,2.158,2.367,'$B$1','Sensitivity (replace Yong)','Composite asthma or death'],
['Atopic dermatitis','Yong 2025','HR (PSM)',1.179,1.140,1.219,'$B$1','Main','AD codes incl. L23–L25'],
['Atopic dermatitis','Clarion 2026 (1–17 y)','HR (PSM, adj.)',1.15,1.004,1.31,'$B$2','Main','Bonferroni-corrected CI in paper'],
['Allergic rhinitis','Yong 2025','HR (PSM)',1.223,1.188,1.259,'$B$1','Main',''],
['Allergic rhinitis','Clarion 2026 (1–17 y)','HR (PSM, adj.)',1.38,1.27,1.50,'$B$2','Main','Rhinoconjunctivitis'],
['Urticaria','Clarion 2026 (1–17 y)','HR (PSM, adj.)',1.20,1.03,1.40,'$B$2','Single study','No pooling unless Lee 2024 or Kim MH 2025 add paediatric data'],
]
for r in ROWS:
    es.append([r[0],r[1],r[2],r[3],r[4],r[5],'Bonferroni' if r[6]=='$B$2' else '95%',None,None,r[7],r[8]])
    i=es.max_row
    for col in 'DEF': es[f'{col}{i}'].font=blue
    es[f'H{i}']=f'=LN(D{i})'; es[f'I{i}']=f'=(LN(F{i})-LN(E{i}))/(2*{r[6]})'
# Schmitt computed from incidence rates
es.append(['Atopic dermatitis','Schmitt 2024 (<18 y)','IRR (from IR)',None,None,None,'from events',None,None,'Main','IR 14.59 vs 10.70 /1000 PY; events 622 vs 456 (weighted). Confirm CI with authors'])
i=es.max_row
es[f'D{i}']='=L{0}/M{0}'.format(i); es[f'H{i}']=f'=LN(D{i})'; es[f'I{i}']=f'=SQRT(1/N{i}+1/O{i})'
es[f'E{i}']=f'=EXP(H{i}-$B$1*I{i})'; es[f'F{i}']=f'=EXP(H{i}+$B$1*I{i})'
es[f'L{hr}']='IR infected'; es[f'M{hr}']='IR controls'; es[f'N{hr}']='Events infected'; es[f'O{hr}']='Events controls'
for col in 'LMNO': es[f'{col}{hr}'].font=hdr; es[f'{col}{hr}'].fill=hfill
es[f'L{i}']=14.59; es[f'M{i}']=10.70; es[f'N{i}']=622; es[f'O{i}']=456
for col in 'LMNO': es[f'{col}{i}'].font=blue
for row in es.iter_rows(min_row=hr+1):
    for x in row:
        x.border=bd; x.alignment=Alignment(wrap_text=True,vertical='top')
        if x.font.color is None or x.font.color.rgb!='FF0000FF': x.font=base
    for c in (row[7],row[8]): c.number_format='0.0000'
    for c in (row[4],row[5]): c.number_format='0.000'
    row[3].number_format='0.000'
widths(es,[18,24,16,10,10,10,14,12,10,22,42,11,11,11,11]); es.freeze_panes=f'A{hr+1}'

# ---------- PRISMA ----------
p=wb.create_sheet('PRISMA',0)
p['A1']='PRISMA 2020 flow – counts'; p['A1'].font=Font(name=F,bold=True,size=13)
data=[('Records identified – PubMed',1061,'From uploaded .nbib'),('Records identified – Scopus',1773,'From uploaded .csv'),
('Records identified – Web of Science',744,'Full export'),('Total identified','=SUM(B3:B5)',''),('Duplicates removed','=B6-B8','DOI → PMID → normalised title'),
('Records screened (title/abstract)','=COUNTA(Screening!A:A)-1',''),('Excluded at title/abstract','=B8-B10',''),
('Reports sought for retrieval','=COUNTA(\'Full-text\'!A:A)-1-B17','Includes Allergologie digest traced to its source (excluded)'),
('Reports not retrieved','=COUNTIF(\'Full-text\'!C:C,"Awaiting full text")','Lee 2024 — update when obtained'),
('Reports assessed for eligibility','=B10-B11',''),
('Excluded: adults only (≥18/≥20 y)','=COUNTIF(\'Full-text\'!D:D,"Wrong population*")',''),
('Excluded: no paediatric estimate','=COUNTIF(\'Full-text\'!C:C,"Exclude (or contact author)")','Author contact possible'),
('Studies included (reports)','=COUNTIF(\'Full-text\'!C:C,"Include*")',''),
('  of which independent cohorts','=B15-1','Yang 2025 overlaps with Yong 2025 (TriNetX US)'),
('Other methods: citation searching – assessed','=COUNTIF(\'Full-text\'!C:C,"*other methods*")','Roessler 2022 (excluded: no outcome of interest)')]
for j,(a,b,cm) in enumerate(data,start=3):
    p.cell(row=j,column=1,value=a).font=base; p.cell(row=j,column=2,value=b).font=blue if isinstance(b,int) else base; p.cell(row=j,column=3,value=cm).font=Font(name=F,size=9,italic=True)
p.column_dimensions['A'].width=40; p.column_dimensions['B'].width=10; p.column_dimensions['C'].width=60
p['A19']='Screening and extraction were done by an AI assistant; PRISMA requires two independent human reviewers — use as reviewer 1.'
p['A19'].font=Font(name=F,size=9,italic=True,color='C00000'); p.merge_cells('A19:C20'); p['A19'].alignment=Alignment(wrap_text=True)

# ---------- Screening (title/abstract) ----------
sc=wb.create_sheet('Screening')
sc.append(list(S.columns))
for x in sc[1]: x.font=hdr; x.fill=hfill
for r in S.itertuples(index=False): sc.append([str(v) if v is not None else '' for v in r])
for row in sc.iter_rows(min_row=2):
    for x in row: x.font=base
    if row[8].value!='Exclude':
        for x in row[:11]: x.fill=G if row[8].value.startswith('Include') else Y
widths(sc,[7,60,30,6,28,26,10,18,26,55,18,80]); sc.freeze_panes='C2'; sc.auto_filter.ref=sc.dimensions
wb.move_sheet('Characteristics',offset=-2)
wb.save('outputs/allergic_postcovid_screening.xlsx')
