# Post-COVID-19 outcomes in children: evidence-synthesis code

Code for two evidence syntheses on post-acute outcomes after SARS-CoV-2 infection in children and adolescents:

1. **Allergic meta-analysis** — new-onset asthma, atopic dermatitis, allergic rhinitis and urticaria after SARS-CoV-2 infection in children: a systematic review and meta-analysis of controlled cohort studies (target journal: *Children*, MDPI).
2. **Umbrella review** — "How much of paediatric long COVID is attributable to infection? An umbrella review of controlled evidence with credibility and certainty grading" (target journal: *Frontiers in Pediatrics*).

Protocols: [OSF DOI — allergic meta-analysis] · [OSF DOI — umbrella review]

## Repository structure

```
allergic_meta_analysis/
  01_import_deduplicate.py              parse PubMed (.nbib), Scopus (.csv), WoS (.xls); deduplicate (DOI → PMID → title)
  02_candidate_filter.py                rule-based pre-filter for manual title/abstract screening
  03_screening_decisions_workbook.py    screening decisions and reasons → Excel workbook
  04_fulltext_characteristics_effectsizes.py  full-text decisions, study characteristics, effect sizes (lnHR, SE)
  05_robins_e_amstar_selfcheck.py       ROBINS-E judgements and AMSTAR 2 self-check sheets
  06_meta_analysis.R                    random-effects meta-analysis (REML + Hartung-Knapp), sensitivity analyses, forest plots
  07_prisma_figure.py                   PRISMA 2020 flow diagram
  part1.py                              helper imported by step 04
umbrella_review/
  01_import_deduplicate.py              parse PubMed (.nbib), Scopus (.ris), WoS (.xls); deduplicate
  02_candidate_flags.py                 flag candidate meta-analyses for manual screening
  02b_screening_decisions.py            screening decisions and reasons
  03_screening_workbook.py              screening workbook and PRISMA counts
  04_amstar2.py                         AMSTAR 2 ratings and overall confidence (Shea et al. 2017 rules)
  05_credibility_grade.py               P values from CIs, restricted credibility classes, GRADE rules
  06a_overlap_cca_t1d.py                citation matrix and CCA — type 1 diabetes reviews
  06b_overlap_cca_symptoms.py           citation matrix and CCA — controlled symptom reviews
  07a_prisma_figure.py                  PRISMA 2020 flow diagram (TIFF, 300 dpi)
  07b_association_figure.py             summary plot of controlled associations (TIFF, 300 dpi)
  08_fulltext_decisions_characteristics.py   full-text decisions and characteristics table
  umbrella_analysis.py                  self-contained script reproducing key calculations (also deposited on OSF)
docs/search_strategies.md               full search strings and dates
data/raw/                               place database exports here (not included — see below)
outputs/                                generated tables and figures
```

## Input data (not included)

Raw database exports are **not** redistributed because of database licence terms (Scopus, Web of Science). To reproduce, run the searches in `docs/search_strategies.md` and save the exports in `data/raw/`:

| Review | PubMed | Scopus | Web of Science |
|---|---|---|---|
| Allergic meta-analysis | `*.nbib` | `export*.csv` | `savedrecs__6_.xls` |
| Umbrella review | `pubmed-Post-Acute*.nbib` | `export_*.ris` | `savedrecs__7_.xls` |

Full texts of included studies are copyrighted and are not included. Manual screening decisions are keyed to record IDs produced by step 01; re-running the searches at a later date will change IDs and counts.

## Requirements

Python ≥ 3.10 (`pip install -r requirements.txt`); R ≥ 4.3 with `metafor` (≥ 4.4).

Run scripts from within their folder, in numerical order. Intermediate files (`*.pkl`) are written to the working directory.

## Notes

- Screening and extraction were supported by an AI assistant (Claude, Anthropic); all decisions were verified by the authors. Rule-based exclusions are labelled in the output workbooks.
- Credibility classes in the umbrella review are a restricted version of Fusar-Poli & Radua (2018) because study-level data were unavailable.

## Licence

Code: MIT (see `LICENSE`). Documentation and derived data: CC BY 4.0.

## Citation

[Authors]. [Title]. [Journal] ([year]). doi: [ ]. Code: [Zenodo DOI].
