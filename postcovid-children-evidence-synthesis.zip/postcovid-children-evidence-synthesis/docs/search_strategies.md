# Search strategies

## Allergic meta-analysis
Searched [date]; from 1 December 2019; no language restriction.

### PubMed/MEDLINE (n = 1061)
```
(("COVID-19"[Mesh] OR "SARS-CoV-2"[Mesh] OR "Post-Acute COVID-19 Syndrome"[Mesh] OR COVID*[tiab] OR "SARS-CoV-2"[tiab] OR "SARS CoV 2"[tiab]) AND ("Asthma"[Mesh] OR asthma*[tiab] OR "Dermatitis, Atopic"[Mesh] OR "atopic dermatitis"[tiab] OR eczema[tiab] OR "Rhinitis, Allergic"[Mesh] OR "allergic rhinitis"[tiab] OR "hay fever"[tiab] OR rhinoconjunctivitis[tiab] OR "Urticaria"[Mesh] OR urticaria[tiab] OR "allergic disease*"[tiab] OR "allergic disorder*"[tiab] OR "atopic disease*"[tiab]) AND (incident*[tiab] OR "new-onset"[tiab] OR "new onset"[tiab] OR "newly diagnosed"[tiab] OR "de novo"[tiab] OR "hazard ratio*"[tiab] OR "post-acute"[tiab] OR "Post-Acute COVID-19 Syndrome"[Mesh] OR sequela*[tiab] OR "Cohort Studies"[Mesh] OR "cohort study"[tiab] OR "cohort studies"[tiab] OR "matched cohort"[tiab] OR "population-based"[tiab]) AND 2019/12/01:3000[dp]) NOT ("Animals"[Mesh] NOT "Humans"[Mesh])
```

### Scopus (n = 1773)
```
TITLE-ABS-KEY(covid* OR "SARS-CoV-2" OR "SARS CoV 2" OR "post-acute COVID-19 syndrome") AND TITLE-ABS-KEY(asthma* OR "atopic dermatitis" OR eczema OR "allergic rhinitis" OR "hay fever" OR rhinoconjunctivitis OR urticaria OR "allergic disease*" OR "allergic disorder*" OR "atopic disease*") AND TITLE-ABS-KEY(incident* OR "new onset" OR "newly diagnosed" OR "de novo" OR "hazard ratio*" OR "post-acute" OR sequela* OR "cohort study" OR "cohort studies" OR "matched cohort" OR "population-based") AND PUBYEAR > 2018
```

### Web of Science Core Collection (n = 744)
```
TS=(covid* OR "SARS-CoV-2" OR "SARS CoV 2" OR "post-acute COVID-19 syndrome") AND TS=(asthma* OR "atopic dermatitis" OR eczema OR "allergic rhinitis" OR "hay fever" OR rhinoconjunctivitis OR urticaria OR "allergic disease*" OR "allergic disorder*" OR "atopic disease*") AND TS=(incident* OR "new onset" OR "newly diagnosed" OR "de novo" OR "hazard ratio*" OR "post-acute" OR sequela* OR "cohort study" OR "cohort studies" OR "matched cohort" OR "population-based") AND PY=(2019-2026)
```

## Umbrella review
Searched 23 September 2026; from 1 January 2020.

### PubMed/MEDLINE (n = 426)
```
("Post-Acute COVID-19 Syndrome"[Mesh] OR "long COVID"[tiab] OR "long-COVID"[tiab] OR "post-COVID*"[tiab] OR "post COVID*"[tiab] OR "post-acute sequela*"[tiab] OR PASC[tiab] OR "post-acute"[tiab] OR "persistent symptom*"[tiab] OR ((COVID*[tiab] OR "SARS-CoV-2"[tiab] OR "COVID-19"[Mesh]) AND (sequela*[tiab] OR "long-term"[tiab] OR persistent[tiab] OR "new-onset"[tiab] OR incident*[tiab]))) AND ("Child"[Mesh] OR "Adolescent"[Mesh] OR "Infant"[Mesh] OR "Pediatrics"[Mesh] OR child*[tiab] OR pediatric*[tiab] OR paediatric*[tiab] OR adolescen*[tiab] OR infant*[tiab] OR youth*[tiab] OR teen*[tiab]) AND ("Systematic Review"[pt] OR "Meta-Analysis"[pt] OR "systematic review"[tiab] OR "meta-analys*"[tiab] OR "meta analys*"[tiab] OR metaanalys*[tiab] OR "umbrella review"[tiab] OR "overview of reviews"[tiab] OR "pooled analysis"[tiab]) AND 2020/01/01:3000[dp]
```

### Scopus (n = 699)
```
TITLE-ABS-KEY("long COVID" OR "long-COVID" OR "post-COVID*" OR "post COVID*" OR "post-acute sequela*" OR PASC OR "post-acute" OR "persistent symptom*" OR ((covid* OR "SARS-CoV-2") AND (sequela* OR "long-term" OR persistent OR "new-onset" OR incident*))) AND TITLE-ABS-KEY(child* OR pediatric* OR paediatric* OR adolescen* OR infant* OR youth* OR teen*) AND TITLE-ABS-KEY("systematic review" OR "meta-analys*" OR "meta analys*" OR metaanalys* OR "umbrella review" OR "overview of reviews" OR "pooled analysis") AND PUBYEAR > 2019
```

### Web of Science Core Collection (n = 532)
```
TS=("long COVID" OR "long-COVID" OR "post-COVID*" OR "post COVID*" OR "post-acute sequela*" OR PASC OR "post-acute" OR "persistent symptom*" OR ((covid* OR "SARS-CoV-2") AND (sequela* OR "long-term" OR persistent OR "new-onset" OR incident*))) AND TS=(child* OR pediatric* OR paediatric* OR adolescen* OR infant* OR youth* OR teen*) AND TS=("systematic review" OR "meta-analys*" OR "meta analys*" OR metaanalys* OR "umbrella review" OR "overview of reviews" OR "pooled analysis") AND PY=(2020-2026)
```
