import pandas as pd,re
u=pd.read_pickle('u.pkl'); c=pd.read_pickle('c.pkl')
INC={205:'Paediatric MA of controlled and uncontrolled studies (persistent symptoms)',24:'Paediatric MA of long-COVID prevalence and symptoms',280:'Paediatric MA: lung imaging/function, cardiorespiratory symptoms ≥3 mo',302:'Paediatric MA of cohort studies: new-onset T1D (controlled)',186:'Paediatric MA: mental health problems in long COVID',72:'Paediatric MA: prevalence and risk factors of long COVID',357:'Paediatric MA of controlled studies: persistent symptoms',136:'Paediatric MA: risk factors for long COVID',122:'Paediatric MA: pulmonary function after infection',64:'Paediatric MA: vaccine effectiveness against PCC',299:'Paediatric MA: burden of long COVID by diagnostic criteria',341:'Paediatric MA: race/ethnicity and long COVID/MIS-C (long-COVID estimates only)',321:'Paediatric MA (metaprop): PCC symptoms in hospitalised children',109:'Paediatric SR with pooled prevalence of persistent symptoms',792:'Book chapter reporting paediatric MA of cognitive impairment (PCNS) — verify peer review'}
CHK={135:'All-age MA of controlled studies; children analysed separately? — check',118:'All-age MA of controlled studies — check paediatric subgroup',207:'All-age MA prevalence/risk ratios — check paediatric subgroup',41:'Living SR with prevalence MA — check paediatric data',26:'All-age SR of long-COVID prevalence — check MA and paediatric subgroup',57:'All-age vaccine-effectiveness MA — check paediatric estimate',669:'All-age VE MA; <18 y estimate reported (1 study) — check',180:'All-age MA of immune-mediated diseases vs controls — check paediatric data',13:'GBD modelled estimates incl. <20 y — check whether meta-analysis eligible',88:'All-age MA of long-term effects — check paediatric data',156:'All-age MA of PCC prevalence — check paediatric subgroup',1212:'All-age MA asymptomatic infection — check paediatric data',708:'MA of myocarditis post-COVID incl. MIS-C — check paediatric post-COVID estimate',1144:'Paediatric SR/MA psychiatric sequelae — conference abstract? check',641:'MA of long-COVID risk factors — check paediatric data',692:'MA of incident diabetes after COVID-19 — check paediatric subgroup'}
UMB={78:'Umbrella review (all ages)',112:'Umbrella review — paediatric',87:'Umbrella review — paediatric PCC symptoms/factors',751:'Umbrella review — PCS definitions',522:'Umbrella review — vaccination and long COVID',398:'Overview of reviews — paediatric long COVID heterogeneity (KEY competitor)',46:'Umbrella review — MIS-C',410:'Umbrella review — COVID prognostic factors',189:'Umbrella review — vaccines'}
EXM={409:'SR without meta-analysis',190:'SR without meta-analysis',89:'SR without meta-analysis',288:'SR without meta-analysis',373:'SR without meta-analysis',252:'SR without meta-analysis',1448:'SR without meta-analysis',153:'SR without meta-analysis',21:'Paediatric studies excluded (adults only)',791:'Paediatric studies excluded',110:'Adult MA (paediatric studies excluded)',241:'Paediatric studies excluded',358:'Adults only',405:'Intervention review (treatment of long COVID), narrative synthesis',162:'Acute-phase neuroimaging, not post-acute',223:'Correction notice (linked to included review)',94:'Acute COVID-19 in children',296:'Acute COVID-19 epidemiology'}
def reason(r):
    t=(r.title+' '+r.abstract).lower(); ti=r.title.lower()
    if re.search(r'protocol',ti): return 'Protocol'
    if re.search(r'mis-c|multisystem inflammatory|pims|kawasaki',ti): return 'MIS-C (distinct entity; outside scope)'
    if re.search(r'vaccin',ti): return 'Vaccine safety/immunogenicity/uptake'
    if re.search(r'pandemic|lockdown|confinement|school closure|during covid|post-covid-19 era|post covid-19 era',ti): return 'Pandemic-period effects, not infection sequelae'
    if re.search(r'pregnan|maternal|neonat|perinatal|intrauterine|birth weight',ti): return 'Maternal/perinatal exposure'
    if not re.search(r'covid|sars-cov|coronavirus',t): return 'Not COVID-19'
    if re.search(r'scoping|narrative|editorial|umbrella|overview',ti): return 'Not a systematic review with meta-analysis'
    if not re.search(r'meta-anal|meta anal|pooled',t): return 'No meta-analysis'
    if not re.search(r'child|pediatric|paediatric|adolesc|infant|youth|teen',t): return 'Adult/general population without paediatric data'
    return 'Not post-acute sequelae of infection in children'
rows=[]
for i,r in u.iterrows():
    if i in INC: d,why,m='Include – full text',INC[i],'Manual'
    elif i in CHK: d,why,m='Full text – check paediatric estimate',CHK[i],'Manual'
    elif i in UMB: d,why,m='Exclude – umbrella/overview (use for citation check)',UMB[i],'Manual'
    elif i in EXM: d,why,m='Exclude',EXM[i],'Manual'
    elif i in c.index: d,why,m='Exclude',reason(r),'Manual (title/abstract)'
    else: d,why,m='Exclude',reason(r),'Rule-based – verify'
    rows.append([i,r.title,str(r.authors)[:100],r.year,r.journal,r.doi,r.pmid,r.found_in,d,why,m,str(r.abstract)[:3000]])
S=pd.DataFrame(rows,columns=['ID','Title','Authors','Year','Journal','DOI','PMID','Found in','Decision','Reason','Screening method','Abstract'])
o={'Include – full text':0,'Full text – check paediatric estimate':1,'Exclude – umbrella/overview (use for citation check)':2,'Exclude':3}
S['o']=S.Decision.map(o); S=S.sort_values(['o','Year'],ascending=[True,False]).drop(columns='o')
S.to_pickle('S.pkl'); print(S.Decision.value_counts()); print(S[S.Decision=='Exclude'].Reason.value_counts())
