import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from PIL import Image
fig,ax=plt.subplots(figsize=(10,11.5)); ax.set_xlim(0,80); ax.set_ylim(0,120); ax.axis('off')
def box(x,y,w,h,t,fc='white',fs=9,bold=False):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.3,rounding_size=0.8',fc=fc,ec='black',lw=1))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,fontweight='bold' if bold else 'normal')
def arr(x1,y1,x2,y2): ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle='->',lw=1))
box(2,110,76,7,'Identification of reviews via databases',fc='#DCE6F1',fs=10,bold=True)
for y,t in [(95,'Identification'),(60,'Screening'),(12,'Included')]: ax.text(-1.5,y,t,rotation=90,va='center',ha='center',fontsize=10,fontweight='bold')
box(2,87,34,17,'Records identified from:\nPubMed (n = 426)\nScopus (n = 699)\nWeb of Science (n = 532)\nTotal (n = 1,657)')
box(42,90,36,11,'Records removed before screening:\nduplicates (n = 767)'); arr(36.3,95.5,41.7,95.5)
box(2,70,34,10,'Records screened\n(n = 890)'); arr(19,86.7,19,80.3)
box(42,62,36,22,'Records excluded (n = 859):\nno meta-analysis (n = 301)\npandemic-period effects (n = 147)\nnot COVID-19 (n = 108)\nvaccine studies (n = 76)\nMIS-C (n = 31)\nother (n = 187)\numbrella reviews/overviews (n = 9)',fs=8); arr(36.3,75,41.7,73)
box(2,50,34,10,'Reports sought for retrieval\n(n = 31)'); arr(19,69.7,19,60.3)
box(42,50,36,10,'Reports not retrieved (n = 2)'); arr(36.3,55,41.7,55)
box(2,32,34,10,'Reports assessed for eligibility\n(n = 29)'); arr(19,49.7,19,42.3)
box(42,22,36,24,'Reports excluded (n = 11):\nno separate pooled paediatric\nestimate (n = 5)\npaediatric data excluded /\nadults only (n = 2)\nMIS-C or acute outcomes only (n = 2)\nconference abstract (n = 1)\nnot a systematic review with\nmeta-analysis (n = 1)',fs=8); arr(36.3,37,41.7,35)
box(2,4,34,14,'Reviews included (n = 18)\n13 paediatric reviews\n5 mixed-age reviews with\nseparate paediatric estimates',fs=9); arr(19,31.7,19,18.3)
plt.savefig('p.png',dpi=300,bbox_inches='tight')
Image.open('p.png').convert('RGB').save('outputs/PRISMA_umbrella_review.tif',dpi=(300,300),compression='tiff_lzw')
