import pandas as pd, json
Y,PY,N='Yes','PY','No'
V=lambda x: x+'*'   # * = verify
rev=['Behnood 2022','Behnood 2023','Lopez-Leon 2022','Campos 2022','Bakhtiari 2024','Mat Hassan 2023','Zheng 2023','Jiang 2023','Silva 2024','Cioni 2026','Rahmati 2023','Lai 2022','Gil 2025','Xu 2024','Luo 2024','Ma 2023','Rayner 2024','Gutfreund 2024']
# items 1..16
R={
'Behnood 2022':   [Y,PY,Y,Y,Y,Y,N,Y,PY,N,Y,Y,Y,Y,N,Y],
'Behnood 2023':   [Y,PY,Y,PY,Y,Y,N,Y,PY,N,Y,N,Y,Y,Y,Y],
'Lopez-Leon 2022':[Y,PY,Y,PY,Y,Y,N,PY,N,N,Y,N,N,N,Y,Y],
'Campos 2022':    [Y,PY,Y,PY,Y,V(N),N,PY,PY,N,Y,N,V(N),N,N,Y],
'Bakhtiari 2024': [Y,N,Y,PY,V(N),Y,N,PY,PY,N,Y,N,V(N),Y,Y,Y],
'Mat Hassan 2023':[Y,PY,Y,PY,Y,Y,N,PY,PY,N,Y,Y,V(Y),Y,Y,Y],
'Zheng 2023':     [Y,PY,Y,PY,Y,Y,N,Y,V(PY),N,Y,N,V(N),Y,Y,Y],
'Jiang 2023':     [Y,N,Y,PY,V(N),V(N),N,PY,PY,N,Y,N,V(N),Y,N,Y],
'Silva 2024':     [Y,PY,Y,PY,V(N),V(N),N,PY,PY,N,Y,N,V(N),Y,N,Y],
'Cioni 2026':     [Y,N,Y,PY,V(N),V(N),Y,Y,PY,N,Y,Y,Y,Y,Y,Y],
'Rahmati 2023':   [Y,PY,Y,PY,V(N),V(N),Y,Y,PY,N,Y,N,V(N),Y,Y,Y],
'Lai 2022':       [Y,PY,Y,PY,Y,Y,N,PY,V(PY),N,Y,N,V(N),Y,Y,Y],
'Gil 2025':       [Y,PY,Y,PY,Y,Y,Y,Y,Y,N,Y,N,Y,Y,Y,Y],
'Xu 2024':        [Y,PY,Y,PY,Y,Y,N,Y,PY,N,Y,N,V(N),Y,Y,V(N)],
'Luo 2024':       [Y,PY,Y,PY,Y,Y,N,Y,PY,N,Y,N,V(N),Y,Y,V(N)],
'Ma 2023':        [Y,PY,Y,PY,V(Y),V(N),N,PY,PY,N,Y,N,V(N),Y,Y,Y],
'Rayner 2024':    [Y,PY,Y,Y,Y,Y,N,Y,Y,N,Y,Y,Y,Y,Y,Y],
'Gutfreund 2024': [Y,PY,Y,PY,V(N),V(N),N,PY,PY,N,Y,N,V(N),N,Y,Y],
}
crit=[2,4,7,9,11,13,15]
rows=[]
for r in rev:
    a=R[r]; clean=[x.rstrip('*') for x in a]
    cf=sum(1 for i in crit if clean[i-1]=='No')
    ncw=sum(1 for i in range(1,17) if i not in crit and clean[i-1]=='No')
    overall='Critically low' if cf>1 else 'Low' if cf==1 else ('Moderate' if ncw>1 else 'High')
    rows.append([r]+a+[cf,ncw,overall])
df=pd.DataFrame(rows,columns=['Review']+[f'Q{i}' for i in range(1,17)]+['Critical flaws','Non-critical weaknesses','Overall confidence'])
df.to_pickle('amstar.pkl'); print(df[['Review','Critical flaws','Non-critical weaknesses','Overall confidence']].to_string())
