import pandas as pd, re, glob
U='data/raw/'
def nbib(path):
    txt=open(path,encoding='utf-8',errors='ignore').read().replace('\r','')
    recs=[]
    for block in re.split(r'\n\s*\n(?=PMID-)',txt.strip()):
        d={};key=None
        for line in block.split('\n'):
            m=re.match(r'^([A-Z]{2,4})\s*- (.*)$',line)
            if m: key=m.group(1); d.setdefault(key,[]).append(m.group(2))
            elif key and line.startswith('      '): d[key][-1]+=' '+line.strip()
        doi=''
        for l in d.get('LID',[])+d.get('AID',[]):
            if '[doi]' in l: doi=l.replace('[doi]','').strip();break
        recs.append(dict(source='PubMed',title=' '.join(d.get('TI',[''])),abstract=' '.join(d.get('AB',[''])),year=d.get('DP',[''])[0][:4],doi=doi,pmid=d.get('PMID',[''])[0].strip(),authors='; '.join(d.get('AU',[])),journal=d.get('JT',[''])[0],doctype='; '.join(d.get('PT',[]))))
    return pd.DataFrame(recs)
def ris(path):
    recs=[];d={}
    for line in open(path,encoding='utf-8',errors='ignore'):
        line=line.rstrip('\r\n'); m=re.match(r'^([A-Z][A-Z0-9])  - ?(.*)$',line)
        if not m: continue
        k,v=m.groups()
        if k=='ER':
            recs.append(dict(source='Scopus',title=' '.join(d.get('TI',[''])),abstract=' '.join(d.get('AB',[''])),year=(d.get('PY',[''])[0])[:4],doi=d.get('DO',[''])[0],pmid='',authors='; '.join(d.get('AU',[])),journal=d.get('T2',[''])[0],doctype=d.get('TY',[''])[0]+'; '+'; '.join(d.get('M3',[]))));d={}
        else: d.setdefault(k,[]).append(v)
    return pd.DataFrame(recs)
pm=nbib(glob.glob(U+'pubmed-Post-Acute*.nbib')[0])
sc=ris(glob.glob(U+'export_892247e8*.ris')[0])
w=pd.read_excel(U+'savedrecs__7_.xls',engine='xlrd')
wo=pd.DataFrame(dict(source='WoS',title=w['Article Title'],abstract=w['Abstract'],year=w['Publication Year'].astype(str),doi=w['DOI'],pmid=w['Pubmed Id'].fillna('').astype(str).str.replace(r'\.0$','',regex=True),authors=w['Authors'],journal=w['Source Title'],doctype=w['Document Type']))
a=pd.concat([pm,sc,wo],ignore_index=True).fillna('')
print(a.source.value_counts().to_dict())
a['doi_n']=a.doi.str.lower().str.strip().str.replace(r'^https?://(dx\.)?doi\.org/','',regex=True)
a['tn']=a.title.map(lambda t:re.sub(r'[^a-z0-9]','',str(t).lower())[:120])
a['found_in']=a.source
keep=[];sd={};sp={};st={}
for i,r in a.iterrows():
    k=sd.get(r.doi_n) if r.doi_n else None
    k=k if k is not None else (sp.get(r.pmid) if r.pmid else None)
    k=k if k is not None else (st.get(r.tn) if len(r.tn)>20 else None)
    if k is not None:
        if r.source not in a.at[k,'found_in']: a.at[k,'found_in']+='; '+r.source
        if not a.at[k,'abstract'] and r.abstract: a.at[k,'abstract']=r.abstract
        if not a.at[k,'pmid'] and r.pmid: a.at[k,'pmid']=r.pmid
        continue
    keep.append(i)
    if r.doi_n: sd[r.doi_n]=i
    if r.pmid: sp[r.pmid]=i
    if len(r.tn)>20: st[r.tn]=i
u=a.loc[keep].copy(); print('total',len(a),'unique',len(u),'dups',len(a)-len(u))
u.to_pickle('u.pkl')
