import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, numpy as np
from PIL import Image
revs=['Behnood\n2022','Behnood\n2023','Lopez-Leon\n2022','Xu 2024\n(<18 y)']
D=[('CLoCk, England (Stephenson; Bertran; Nugawela) ᵃ',[1,1,1,1]),('Ciao Corona, Switzerland (Radtke)',[1,1,1,1]),('Blankenburg, Germany',[1,1,1,0]),('LongCOVIDKidsDK 15–18 y (Kikkenborg Berg)',[0,1,1,1]),('LongCOVIDKidsDK 0–14 y (Kikkenborg Berg)',[0,1,0,1]),('Molteni, UK (app)',[1,0,1,0]),('Knoke, Germany',[1,0,1,0]),('Bergia, Spain',[0,1,0,1]),('Funk, 8 countries (ED)',[0,1,0,1]),('Haddad, Germany',[0,1,0,1]),('Chevinsky, USA',[1,0,0,0]),('Di Sante, Italy',[1,0,0,0]),('Zavala, UK',[1,0,0,0]),('Clavenna, Italy',[0,1,0,0]),('Donnachie, Germany',[0,1,0,0]),('Roessler, Germany',[0,1,0,0]),('Dumont, Switzerland',[0,1,0,0]),('Borch, Denmark',[0,0,1,0]),('Erol, Turkey',[0,0,1,0]),('Fink, Brazil',[0,0,1,0]),('Buonsenso, Italy',[0,0,0,1]),('van der Maaden, Netherlands',[0,0,0,1]),('Seery, Argentina',[0,0,0,1])]
M=np.array([d[1] for d in D]); r,c=M.shape; N=M.sum(); cca=(N-r)/(r*c-r)
pair={}
for a in range(c):
    for b in range(a+1,c):
        S=M[:,[a,b]]; S=S[S.sum(1)>0]; rr=len(S); nn=S.sum(); pair[(a,b)]=(nn-rr)/(rr*2-rr)
print(r,c,N,round(cca*100,1)); print({f'{revs[a]}–{revs[b]}'.replace('\n',' '):round(v*100,1) for (a,b),v in pair.items()})
fig,ax=plt.subplots(figsize=(7.5,8))
ax.imshow(M,cmap='Blues',vmin=0,vmax=1.6,aspect='auto')
for i in range(r):
    for j in range(c):
        if M[i,j]: ax.text(j,i,'●',ha='center',va='center',fontsize=10,color='#0B3C68')
ax.set_xticks(range(c)); ax.set_xticklabels(revs,fontsize=9); ax.xaxis.tick_top()
ax.set_yticks(range(r)); ax.set_yticklabels([d[0] for d in D],fontsize=8)
ax.set_xticks(np.arange(-.5,c),minor=True); ax.set_yticks(np.arange(-.5,r),minor=True); ax.grid(which='minor',color='white',lw=2); ax.tick_params(which='minor',length=0)
ax.set_title(f'Persistent symptoms vs uninfected controls — citation matrix (cohort level)\nCCA = {cca*100:.1f}% (very high overlap)',fontsize=10,pad=38)
fig.text(0.01,0.005,'ᵃ Several publications from the same cohort counted once. Provisional — confirm controlled-study lists against each review (second reviewer).',fontsize=7,style='italic')
plt.tight_layout(); plt.savefig('cca2.png',dpi=300,bbox_inches='tight')
Image.open('cca2.png').convert('RGB').save('outputs/Umbrella_CCA_symptoms.tif',dpi=(300,300),compression='tiff_lzw')
