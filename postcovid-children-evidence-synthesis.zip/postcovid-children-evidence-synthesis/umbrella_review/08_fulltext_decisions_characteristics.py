from openpyxl import load_workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.utils import get_column_letter
P='outputs/umbrella_review_screening.xlsx'
wb=load_workbook(P); F='Arial'
hdr=Font(name=F,bold=True,color='FFFFFF'); hf=PatternFill('solid',fgColor='1F4E78'); base=Font(name=F,size=10)
G=PatternFill('solid',fgColor='E2EFDA'); R=PatternFill('solid',fgColor='F8CBAD'); Y=PatternFill('solid',fgColor='FFF2CC')
thin=Side(style='thin',color='BFBFBF'); bd=Border(top=thin,bottom=thin,left=thin,right=thin)
def sheet(name,cols,rows,widths,colorcol=None,pos=None):
    if name in wb.sheetnames: del wb[name]
    ws=wb.create_sheet(name,pos); ws.append(cols)
    for x in ws[1]: x.font=hdr; x.fill=hf; x.alignment=Alignment(wrap_text=True,vertical='center')
    for r in rows:
        ws.append(r)
        for x in ws[ws.max_row]:
            x.font=base; x.border=bd; x.alignment=Alignment(wrap_text=True,vertical='top')
        if colorcol is not None:
            v=str(r[colorcol]); f=G if v.startswith('Include') else R if v.startswith('Exclude') else Y
            for x in ws[ws.max_row]: x.fill=f
    for j,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(j)].width=w
    ws.freeze_panes='B2'
FT=[
['Behnood 2022, J Infect','10.1016/j.jinf.2021.11.011','Include','Paediatric SR/MA; controlled (risk difference, 5 studies) and uncontrolled (prevalence, 17 studies) syntheses'],
['Behnood 2023, PLoS One','10.1371/journal.pone.0293600','Include','Update of Behnood 2022 (55 studies); MA of 21 symptoms from 11 controlled studies — overlaps with Behnood 2022 (same group, same registration)'],
['Campos 2022, Healthcare','10.3390/healthcare10122492','Include','Paediatric one-group MA (17 studies): lung imaging/function, cardiorespiratory symptoms, fatigue, exercise capacity ≥3 mo'],
['Bakhtiari 2024, BMC Pediatr','10.1186/s12887-024-04560-1','Include','Paediatric MA (8 studies, 386 children): pooled spirometry means after infection'],
['Mat Hassan 2023, PLoS One','10.1371/journal.pone.0282538','Include','Paediatric MA (13 studies): prevalence of mental health problems; ORs vs uninfected (anxiety, depression, appetite)'],
['Gutfreund 2024, Antimicrob Steward Healthc Epidemiol','10.1017/ash.2024.42','Include','Paediatric MA (<21 y; 5 studies): vaccination vs no vaccination and PCC (DOR 1.07; 2 doses 0.82)'],
['Cioni 2026, J Clin Med','10.3390/jcm15145597','Include','Paediatric MA (52 cohorts, 960,089 children): LC rate 18.1%; risk factors; vaccination OR 0.92'],
['Gil 2025, Semin Arthritis Rheum','10.1016/j.semarthrit.2025.152805','Include (paediatric estimate only)','All-age MA of immune-mediated diseases vs uninfected; separate paediatric T1D pooled RR 0.70 (0.29–1.68), 2 studies'],
['Azzam 2024, Virology J','10.1186/s12985-024-02284-3','Exclude','Mixed-age MA of controlled studies; no separate paediatric pooled estimate (4 paediatric studies pooled with adults) — use primary paediatric studies for discussion'],
['Cotet 2025, J Clin Med','10.3390/jcm14197008','Exclude','Paediatric post-COVID myocarditis data derive from MIS-C cohorts; no separate paediatric non-MIS-C estimate'],
['Bergqvist 2026, BMC Infect Dis','10.1186/s12879-026-12848-z','Exclude','Meta-analyses restricted to acute severity and MIS-C; long-COVID outcomes synthesised narratively only'],
['Japi 2024, JAACAP (poster abstract)','10.1016/j.jaac.2024.08.425','Exclude','Conference abstract (no full report). Note: controlled MA of 8 studies, any mental disorder OR 1.39 (0.98–1.97) — cite in discussion / search for full publication'],
['Appel 2026, BMC Pediatr','10.1186/s12887-026-07276-6','Exclude – overview of reviews','Competitor: narrative overview (69 primary studies, search to Apr 2024); correlations of methods with prevalence; no effect-size synthesis or credibility grading'],
['Jiang 2023, Pediatrics','10.1542/peds.2022-060351','Include','Paediatric MA (27 cohorts, 4 cross-sectional; >15,000): ≥1 persistent symptom ≥3 mo 16.2% (8.5–28.6)'],
['Zheng 2023, J Infect Public Health','10.1016/j.jiph.2023.03.005','Include','Paediatric MA (40 studies, 12,424): any long COVID 23.4% (15.3–32.5); risk factors'],
['Rahmati 2023, J Med Virol','10.1002/jmv.28833','Include','Paediatric MA of controlled cohorts: new-onset T1D RR 1.42 (1.13–1.77); DKA RR 2.56 (1.07–6.11)'],
['Rayner 2024, World J Pediatr','10.1007/s12519-023-00765-z','Include','Paediatric MA of risk factors (16 studies, 46,262; GRADE, QUIPS)'],
['Xu 2024, J Glob Health','10.7189/jogh.14.05022','Include (paediatric subgroup)','All-age MA of controlled studies; separate <18 y ORs for 26 symptoms (e.g. ≥1 symptom OR 1.99, 8 studies)'],
['Lai 2022, Metabolism','10.1016/j.metabol.2022.155330','Include (paediatric subgroup)','All-age MA of incident diabetes vs controls; 0–18 y RR 1.74 (1.35–2.24)'],
['Luo 2024, Clin Microbiol Infect','10.1016/j.cmi.2023.10.016','Include (paediatric subgroup) — verify supplement','All-age MA (211 studies); age subgroup shows lower prevalence in children; paediatric pooled values in supplementary figures'],
['Ma 2023, IJERPH','10.3390/ijerph20021613','Include (paediatric subgroup)','MA of asymptomatic infection; separate pooled prevalence for children (2 studies) — very limited'],
['Lopez-Leon 2021, Sci Rep','10.1038/s41598-021-95565-8','Exclude','Adults; no paediatric data'],
['Marra 2022, ASHE','10.1017/ash.2022.336','Exclude','Paediatric studies excluded'],
['Michelen 2021, BMJ Glob Health','10.1136/bmjgh-2021-005427','Exclude','No separate paediatric estimate (4/39 studies included children)'],
['Peine 2025, Clin Microbiol Infect','10.1016/j.cmi.2025.07.026','Exclude','Paediatric VE from a single study (26%, −4 to 48) — not a pooled estimate'],
['Taher 2025, HPCDP','10.24095/hpcdp.45.3.02','Exclude','Paediatric data from 2 studies described narratively; no pooled paediatric estimate'],
['Woodrow 2023, OFID','10.1093/ofid/ofad233','Exclude','No separate pooled paediatric estimate'],
['Wulf Hanson 2022, JAMA','10.1001/jama.2022.18931','Exclude','GBD Bayesian meta-regression of pooled cohort data, not a systematic review with conventional MA (<20 y modelled estimates — cite in discussion)'],
['Lopez-Leon 2022, Sci Rep','10.1038/s41598-022-13495-5','Awaiting full text','Uploaded file was Lopez-Leon 2021 (adult review)'],
['Silva 2024, Pediatr Pulmonol','10.1002/ppul.27257','Awaiting full text',''],
['Murphy 2026, book chapter','10.1007/978-3-032-14995-4_11','Awaiting full text',''],
['Agarwal 2025, J Public Health','10.1007/s10389-024-02246-7','Awaiting full text',''],
]
sheet('Full-text',['Review','DOI','Decision','Reason'],FT,[36,32,26,90],colorcol=2,pos=1)
CH=[
['Behnood 2022','J Infect','Jul 2021','CRD42021233153','22 (8 with controls)','23,141','≤19 y','Symptoms ≥12 wk','Controlled RD (5 studies): cognitive difficulties 3% (1–4), headache 5% (1–8), loss of smell 8% (2–15), sore throat 2% (1–2), sore eyes 2% (1–3); no excess for abdominal pain, cough, fatigue, myalgia, insomnia, diarrhoea, fever, dizziness, dyspnoea','JBI / NOS','Yes'],
['Behnood 2023','PLoS One','Nov 2022','CRD42021233153','55 (11 controlled in MA)','1,139,299','≤19 y','Symptoms ≥12 wk','Higher pooled proportions vs controls for altered/loss of smell or taste, dyspnoea, fatigue, myalgia (21 symptoms meta-analysed); high heterogeneity','JBI / NOS','Yes — overlaps Behnood 2022'],
['Campos 2022','Healthcare','May 2022','CRD42022327478','17','124,568','Children/adolescents','≥3 mo','Prevalence: lung imaging abnormalities 10%, abnormal pulmonary function 24%, dyspnoea 16%, fatigue 24%, reduced exercise capacity 20%, functional limitation 48%','[extract]','No'],
['Bakhtiari 2024','BMC Pediatr','Mar 2023','[not reported]','8','386','Children','Follow-up after infection','Pooled % predicted: FEV1 101.7, FVC 101.3, FEV1/FVC 96.2, FEF25–75 105.1, DLCO 105.3 — no impairment','NOS','No'],
['Mat Hassan 2023','PLoS One','May 2022','CRD42022335716','13','[extract]','Children/adolescents','Long COVID','OR vs uninfected: anxiety/depression >2-fold, appetite problems +14%; prevalence anxiety 9%, depression 15%, sleep 9%','[extract]','Partly (comparative ORs)'],
['Gutfreund 2024','ASHE','Aug 2023','CRD42023456888','8 (5 in MA)','23,995','<21 y','Symptoms ≥4 wk','Vaccinated vs unvaccinated DOR 1.07 (0.77–1.49); 2 doses 0.82 (0.63–1.08)','[extract]','Comparison by vaccination (not infection)'],
['Cioni 2026','J Clin Med','Oct 2025','[not reported]','52 cohorts','960,089','Children/adolescents','LC by NIH/WHO criteria','LC 18.1% (13.1–23.6); higher odds in females, adolescents, comorbidities, severe COVID-19; vaccination OR 0.92 (0.61–1.41)','NOS','No (infected-only cohorts)'],
['Gil 2025 (paediatric T1D)','Semin Arthritis Rheum','[extract]','CRD42023472446','2 paediatric studies','~2.96 M','Children','30 d–28 mo','New-onset T1D: RR 0.70 (0.29–1.68)','ROBINS-E','Yes'],
['Jiang 2023','Pediatrics','Dec 2022','[not reported]','31','>15,000','Children/adolescents','≥3 mo','≥1 persistent symptom 16.2% (8.5–28.6)','[extract]','No'],
['Zheng 2023','J Infect Public Health','[extract]','CRD42021293614','40','12,424','Children/adolescents','Long COVID','Any long COVID 23.4% (15.3–32.5); dyspnoea 22.8%, fatigue 20.2%, headache 15.9%; 3–6 mo 26.4%, >12 mo 14.9%','[extract]','No'],
['Rahmati 2023','J Med Virol','Mar 2023','CRD42023417425','[extract]','[extract]','0–17 y','New-onset T1D','T1D RR 1.42 (1.13–1.77), I² 91%; 0–11 y 1.67 (1.32–2.12); 12–17 y 1.10 (0.54–2.23); USA 1.70 vs Europe 1.02; DKA 2.56 (1.07–6.11)','[extract]','Yes'],
['Rayner 2024','World J Pediatr','May 2023','CRD42023402878','16','46,262','Children/adolescents','Long COVID','Moderate certainty: age, allergic rhinitis, obesity, prior respiratory disease, hospitalisation, severe and symptomatic acute COVID-19 ↑ risk','QUIPS; GRADE','No (risk factors among infected)'],
['Xu 2024 (<18 y)','J Glob Health','Feb 2023','[extract]','8 paediatric','[extract]','<18 y','Symptoms ≥3 mo vs uninfected','≥1 symptom OR 1.99 (1.66–2.39); fatigue 2.03; dyspnoea 2.48; headache 1.53; dizziness 1.81; cough 1.65; throat pain 1.96; chest pain 1.75; n.s.: cognitive 1.16, anxiety 1.15, depression 0.84, sleep 1.10, GI 1.15, abdominal pain 1.00','[extract]','Yes'],
['Lai 2022 (0–18 y)','Metabolism','[extract]','[extract]','[extract]','[extract]','0–18 y','Incident diabetes','RR 1.74 (1.35–2.24)','[extract]','Yes'],
['Luo 2024 (children)','Clin Microbiol Infect','Jan 2023','[extract]','[extract]','[extract]','Children subgroup','Persistent symptoms','Lower prevalence in children (values from supplement)','JBI','Partly'],
['Ma 2023 (children)','IJERPH','[extract]','[extract]','2 paediatric','[extract]','Children','After asymptomatic infection','Paediatric pooled prevalence (supplement)','[extract]','No'],
]
sheet('Characteristics (draft)',['Review','Journal','Search end','Registration','Primary studies','Participants','Age','PCC definition','Key pooled results','Primary-study RoB tool','Controlled (infected vs uninfected) estimates?'],CH,[16,16,11,18,16,12,14,16,70,14,20],pos=2)
wb.save(P)
