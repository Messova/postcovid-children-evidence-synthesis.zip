"""Flag candidate meta-analyses on paediatric post-COVID outcomes (input for manual screening)."""
import pandas as pd
u = pd.read_pickle('u.pkl')
T = u.title.str.lower(); A = (u.title + ' ' + u.abstract).str.lower()
u['ma'] = A.str.contains(r'meta-analy|meta analy|metaanaly|pooled prevalence|pooled estimate|umbrella') | u.doctype.str.contains('Meta-Analysis')
u['pc'] = A.str.contains(r'long covid|long-covid|post-covid|post covid|postcovid|post-acute|post acute|pasc|persistent symptom|sequela|long-term|long term|lingering|pims|mis-c|multisystem')
u['ped'] = A.str.contains(r'child|pediatric|paediatric|adolescen|infant|youth|teen|neonat|young people|school')
u['proto'] = T.str.contains(r'protocol')
c = u[u.ma & u.pc & u.ped & ~u.proto]
print(len(u), int(u.ma.sum()), len(c))
c.to_pickle('c.pkl')
for i, r in c.sort_values('year').iterrows():
    print(i, '|', r.year, '|', r.title[:170])
