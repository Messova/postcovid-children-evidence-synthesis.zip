import math, pandas as pd
from scipy.stats import norm
def p_ratio(e,l,u): se=(math.log(u)-math.log(l))/(2*1.959964); z=abs(math.log(e))/se; return 2*norm.sf(z)
def p_diff(e,l,u): se=(u-l)/(2*1.959964); z=abs(e)/se if se>0 else 0; return 2*norm.sf(z)
A=[ # outcome, domain, source, measure, est, lo, hi, k, I2, note
('≥1 persistent symptom','Any','Xu 2024','OR',1.989,1.656,2.390,8,82.1,''),
('Dyspnoea','Respiratory','Xu 2024','OR',2.481,1.486,4.141,7,96.3,'Also Lopez-Leon 2022 OR 2.69 (2.30–3.14); Behnood 2023 RD 3%'),
('Cough','Respiratory','Xu 2024','OR',1.649,1.057,2.572,6,94.6,''),
('Throat pain','Respiratory','Xu 2024','OR',1.955,1.200,3.185,4,94.3,''),
('Fatigue','General','Xu 2024','OR',2.026,1.355,3.031,6,82.7,'Behnood 2023 RD 4% (2–7), k=10'),
('Fever, sweats or chills','General','Xu 2024','OR',1.815,0.912,3.612,4,89.8,'Lopez-Leon 2022 OR 2.23 (1.20–4.07)'),
('Headache','Neurological','Xu 2024','OR',1.534,1.045,2.251,6,94.1,''),
('Dizziness','Neurological','Xu 2024','OR',1.812,1.193,2.753,6,89.9,''),
('Cognitive difficulties','Neurological','Xu 2024','OR',1.155,0.895,1.490,5,26.0,'Behnood 2023 RD 1% (0–2), k=9'),
('Altered/loss of smell or taste','Neurological','Behnood 2023','RD',0.04,0.02,0.06,5,None,'Lopez-Leon 2022 OR 10.68 (2.48–46.03)'),
('Chest pain','Cardiovascular','Xu 2024','OR',1.750,1.069,2.866,5,92.8,''),
('Palpitations','Cardiovascular','Xu 2024','OR',1.290,0.760,2.190,4,85.1,''),
('Muscle pain','Musculoskeletal','Xu 2024','OR',1.484,0.683,3.223,3,94.8,'Behnood 2023 RD 1% (1–2), k=7'),
('Skin rash','Dermatological','Xu 2024','OR',1.010,0.745,1.369,3,58.3,''),
('Hair loss','Dermatological','Xu 2024','OR',0.923,0.718,1.188,2,0.0,''),
('Gastrointestinal symptoms','Gastrointestinal','Xu 2024','OR',1.154,0.945,1.411,4,0.0,''),
('Abdominal pain','Gastrointestinal','Xu 2024','OR',1.000,0.592,1.689,2,96.6,''),
('Loss of appetite','Gastrointestinal','Behnood 2023','RD',0.01,-0.005,0.03,5,None,'Mat Hassan 2023 OR 1.14 (1.03–1.25), k=3'),
('Sleep problems','Mental health','Xu 2024','OR',1.098,0.485,2.488,3,43.8,''),
('Anxiety','Mental health','Xu 2024','OR',1.148,0.650,2.029,4,74.2,'Mat Hassan 2023 OR 2.11 (1.25–3.57), k=3'),
('Depression','Mental health','Xu 2024','OR',0.843,0.405,1.756,3,68.2,'Mat Hassan 2023 OR 2.15 (1.23–3.74), k=2'),
('New-onset type 1 diabetes','Metabolic','Gil 2025','RR',0.70,0.29,1.68,2,None,'Rahmati 2023 RR 1.42 (1.13–1.77), k=7; Lai 2022 RR 1.74 (1.35–2.24), k=5 — include diagnoses ≤30 d'),
('Diabetic ketoacidosis','Metabolic','Rahmati 2023','RR',2.56,1.07,6.11,2,None,''),
]
rows=[]
for o,d,s,m,e,l,u,k,i2,n in A:
    p=p_diff(e,l,u) if m=='RD' else p_ratio(e,l,u)
    # Ioannidis (restricted: study-level criteria unavailable)
    cls='NS' if p>=0.05 else ('IV' if p>=1e-3 else ('III' if p>=1e-6 else 'III*'))
    if p<1e-6: cls='III ᵇ'
    # GRADE: start low; RoB serious (-1); inconsistency I2>75 (-1); imprecision: CI includes null or k<3 (-1)
    down=1
    if i2 is not None and i2>75: down+=1
    null=(l<=0<=u) if m=='RD' else (l<=1<=u)
    if null or k<3: down+=1
    g='Low' if down==0 else 'Very low'
    est=f'{e:.2f} ({l:.2f}–{u:.2f})' if m!='RD' else f'{e*100:.0f}% ({l*100:.0f} to {u*100:.0f})'
    rows.append([o,d,s,m,est,k,'NR' if i2 is None else f'{i2:.0f}', ('<0.001' if p<0.001 else f'{p:.3f}') if p>=1e-6 else f'{p:.1e}', cls, g, n])
df=pd.DataFrame(rows,columns=['Outcome','Domain','Source review','Measure','Estimate (95% CI)','k','I² (%)','P','Credibility class ᵃ','GRADE','Other reviews (sensitivity)'])
df.to_pickle('grade.pkl'); print(df[['Outcome','Estimate (95% CI)','k','P','Credibility class ᵃ','GRADE']].to_string())
