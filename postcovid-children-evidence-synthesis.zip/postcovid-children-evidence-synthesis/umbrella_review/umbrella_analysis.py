"""
Umbrella review: post-COVID-19 condition in children and adolescents
Analysis script (Python 3). Reproduces:
  1) P values from reported 95% CIs,
  2) restricted credibility classes (Fusar-Poli & Radua 2018; study-level criteria unavailable),
  3) rule-based GRADE rating,
  4) corrected covered area (CCA; Pieper et al. 2014) from citation matrices,
  5) absolute excess risk and attributable fraction implied by the pooled OR for >=1 persistent symptom.
Input: associations.csv (one row per outcome; columns documented below) and citation_matrix_*.csv.
If input files are absent, the embedded example data used in the manuscript are analysed.
"""
import math, csv, os
from statistics import NormalDist
Z = NormalDist().inv_cdf(0.975)

def p_from_ci(est, lo, hi, measure):
    if measure == "RD":                       # difference scale
        se = (hi - lo) / (2 * Z); z = abs(est) / se
    else:                                     # ratio scale (OR, RR, HR)
        se = (math.log(hi) - math.log(lo)) / (2 * Z); z = abs(math.log(est)) / se
    return 2 * (1 - NormalDist().cdf(z))

def credibility(p, cases_over_1000=True):
    """Restricted classes: III (P<1e-3, >1000 cases), IV (P<0.05), NS. Classes I-II not assessable."""
    if p >= 0.05: return "NS"
    if p < 1e-3 and cases_over_1000: return "III (P<1e-6)" if p < 1e-6 else "III"
    return "IV"

def grade(i2, lo, hi, k, measure):
    """Start LOW (observational); -1 risk of bias (always serious: self-report, selection, non-response);
       -1 inconsistency if I2>75%; -1 imprecision if 95% CI includes null or k<3. Floor = VERY LOW."""
    down = 1
    if i2 is not None and i2 > 75: down += 1
    null = (lo <= 0 <= hi) if measure == "RD" else (lo <= 1 <= hi)
    if null or k < 3: down += 1
    return "Low" if down == 0 else "Very low"

def cca(matrix):
    """matrix: list of rows (primary studies) x columns (reviews), entries 0/1."""
    r = len(matrix); c = len(matrix[0]); N = sum(map(sum, matrix))
    return (N - r) / (r * c - r)

def attributable(p1, OR):
    o0 = (p1 / (1 - p1)) / OR; p0 = o0 / (1 + o0)
    return p0, p1 - p0, (p1 - p0) / p1

EXAMPLE = [  # outcome, source, measure, estimate, lower, upper, k, I2 (None if not reported)
 ("≥1 persistent symptom","Xu 2024","OR",1.989,1.656,2.390,8,82.1),
 ("Dyspnoea","Xu 2024","OR",2.481,1.486,4.141,7,96.3),
 ("Fatigue","Xu 2024","OR",2.026,1.355,3.031,6,82.7),
 ("Altered/loss of smell or taste","Behnood 2023","RD",0.04,0.02,0.06,5,None),
 ("Cognitive difficulties","Xu 2024","OR",1.155,0.895,1.490,5,26.0),
 ("New-onset type 1 diabetes","Gil 2025","RR",0.70,0.29,1.68,2,None),
]

def load_associations(path="associations.csv"):
    if not os.path.exists(path): return EXAMPLE
    rows=[]
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            i2 = None if r["I2"] in ("", "NR") else float(r["I2"])
            rows.append((r["outcome"], r["source"], r["measure"], float(r["estimate"]), float(r["lower"]),
                         float(r["upper"]), int(r["k"]), i2))
    return rows

if __name__ == "__main__":
    print("Outcome | Source | Estimate (95% CI) | k | I2 | P | Credibility | GRADE")
    for o, s, m, e, l, u, k, i2 in load_associations():
        p = p_from_ci(e, l, u, m)
        print(f"{o} | {s} | {m} {e} ({l}-{u}) | {k} | {i2} | {p:.2e} | {credibility(p)} | {grade(i2, l, u, k, m)}")
    # CCA example: type 1 diabetes (rows = primary publications; columns = Rahmati, Lai, Gil)
    t1d = [[1,1,0],[1,1,0],[0,0,1],[1,0,0],[1,1,0],[0,1,0],[1,0,0],[1,1,0],[1,0,1]]
    print(f"\nCCA type 1 diabetes (publication level): {100*cca(t1d):.1f}%")
    # Attributable burden
    for p1 in (0.162, 0.181, 0.234, 0.252):
        p0, ex, af = attributable(p1, 1.99)
        print(f"p1={p1:.3f}: p0={p0:.3f}, excess={100*ex:.1f} pp, attributable fraction={100*af:.0f}%")
