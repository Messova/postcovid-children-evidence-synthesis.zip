import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from PIL import Image
import pickle
A=pd.read_pickle('grade.pkl')
d=A[A.Measure!='RD'].copy()
d[['e','l','u']]=d['Estimate (95% CI)'].str.extract(r'([\d.]+) \(([\d.]+)–([\d.]+)\)').astype(float)
d=d.iloc[::-1]
colors={'III ᵇ':'#1B7837','III':'#5AAE61','IV':'#E6A817','NS':'#9E9E9E'}
fig,ax=plt.subplots(figsize=(8,9))
y=np.arange(len(d))
for yi,(_,r) in zip(y,d.iterrows()):
    c=colors[r['Credibility class ᵃ']]
    ax.plot([r.l,r.u],[yi,yi],color=c,lw=1.6); ax.plot(r.e,yi,'s',color=c,ms=6)
    ax.text(9.2,yi,f"{r.e:.2f} ({r.l:.2f}–{r.u:.2f})  k={r.k}",va='center',fontsize=8)
ax.axvline(1,color='black',lw=0.8,ls='--'); ax.set_xscale('log'); ax.set_xlim(0.25,8); ax.set_xticks([0.25,0.5,1,2,4,8]); ax.set_xticklabels(['0.25','0.5','1','2','4','8'])
ax.set_yticks(y); ax.set_yticklabels([f"{o} ({s})" for o,s in zip(d.Outcome,d['Source review'])],fontsize=8.5)
ax.set_xlabel('Odds/risk ratio vs uninfected children (log scale)')
from matplotlib.lines import Line2D
ax.legend([Line2D([0],[0],color=v,marker='s',lw=1.6) for v in colors.values()],['Class III (P<10⁻⁶)','Class III','Class IV','Not significant'],loc='upper center',bbox_to_anchor=(0.5,-0.07),ncol=4,fontsize=8,frameon=False)
ax.set_title('Post-acute outcomes after SARS-CoV-2 infection in children:\nassociations from meta-analyses of controlled studies',fontsize=10)
plt.tight_layout(); plt.savefig('uplot.png',dpi=300,bbox_inches='tight')
Image.open('uplot.png').convert('RGB').save('outputs/Umbrella_Figure_associations.tif',dpi=(300,300),compression='tiff_lzw')
