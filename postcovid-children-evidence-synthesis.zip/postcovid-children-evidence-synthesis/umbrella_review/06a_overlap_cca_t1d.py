import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, numpy as np
from PIL import Image
reviews=['Rahmati 2023','Lai 2022\n(0–18 y)','Gil 2025\n(paediatric)']
prim=[('Barrett 2022 – IQVIA (USA)',[1,1,0]),('Barrett 2022 – HealthVerity (USA)',[1,1,0]),('Kompaniyets 2022 – HealthVerity (USA) ᵃ',[0,0,1]),('Kendall 2022 – TriNetX (USA)',[1,0,0]),('Qeadan 2022 – Cerner (USA)',[1,1,0]),('Pietropaolo 2022 – USA',[0,1,0]),('Gulseth 2022 – Norway',[1,0,0]),('McKeigue 2022 – Scotland ᵇ',[1,1,0]),('Noorzae 2023 – Denmark',[1,0,1])]
M=np.array([p[1] for p in prim]); r,c=M.shape; N=M.sum()
cca=(N-r)/(r*c-r)
# dataset-level: merge Kompaniyets into HealthVerity
M2=M.copy(); M2[1]=np.maximum(M2[1],M2[2]); M2=np.delete(M2,2,0); r2=M2.shape[0]; N2=M2.sum(); cca2=(N2-r2)/(r2*c-r2)
print(r,c,N,round(cca*100,1),r2,N2,round(cca2*100,1))
fig,ax=plt.subplots(figsize=(7,4.6))
ax.imshow(M,cmap='Blues',vmin=0,vmax=1.6,aspect='auto')
for i in range(r):
    for j in range(c):
        if M[i,j]: ax.text(j,i,'●',ha='center',va='center',fontsize=12,color='#0B3C68')
ax.set_xticks(range(c)); ax.set_xticklabels(reviews,fontsize=9); ax.xaxis.tick_top()
ax.set_yticks(range(r)); ax.set_yticklabels([p[0] for p in prim],fontsize=8.5)
ax.set_xticks(np.arange(-.5,c),minor=True); ax.set_yticks(np.arange(-.5,r),minor=True); ax.grid(which='minor',color='white',lw=2); ax.tick_params(which='minor',length=0)
ax.set_title(f'New-onset type 1 diabetes — citation matrix\nCCA = {cca*100:.1f}% (publication level); {cca2*100:.1f}% (dataset level)',fontsize=10,pad=40)
fig.text(0.01,0.01,'ᵃ Same HealthVerity claims data as Barrett 2022. ᵇ Lai used the estimate for the first 30 days after infection (RR 3.15). CCA > 15% = very high overlap.',fontsize=7,style='italic')
plt.tight_layout(); plt.savefig('cca.png',dpi=300,bbox_inches='tight')
Image.open('cca.png').convert('RGB').save('outputs/Umbrella_CCA_T1D.tif',dpi=(300,300),compression='tiff_lzw')
