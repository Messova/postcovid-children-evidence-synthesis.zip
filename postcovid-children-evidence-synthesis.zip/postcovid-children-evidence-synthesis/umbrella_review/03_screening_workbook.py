import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.utils import get_column_letter
S=pd.read_pickle('S.pkl'); F='Arial'
hdr=Font(name=F,bold=True,color='FFFFFF'); hf=PatternFill('solid',fgColor='1F4E78'); base=Font(name=F,size=10); blue=Font(name=F,size=10,color='0000FF')
G=PatternFill('solid',fgColor='E2EFDA'); Y=PatternFill('solid',fgColor='FFF2CC'); B=PatternFill('solid',fgColor='DDEBF7')
wb=Workbook()
inc=wb.active; inc.title='Included & to check'
cols=['ID','Title','Year','Journal','DOI','Decision','Reason']
inc.append(cols)
for x in inc[1]: x.font=hdr; x.fill=hf; x.alignment=Alignment(wrap_text=True)
for _,r in S[S.Decision!='Exclude'].iterrows():
    inc.append([r.ID,r.Title,r.Year,r.Journal,r.DOI,r.Decision,r.Reason])
    f=G if r.Decision.startswith('Include') else Y if r.Decision.startswith('Full') else B
    for x in inc[inc.max_row]: x.fill=f; x.font=base; x.alignment=Alignment(wrap_text=True,vertical='top')
for j,w in enumerate([6,70,6,30,28,30,55],1): inc.column_dimensions[get_column_letter(j)].width=w
inc.freeze_panes='B2'
p=wb.create_sheet('PRISMA')
p['A1']='PRISMA 2020 – umbrella review (full-text stage pending)'; p['A1'].font=Font(name=F,bold=True,size=13)
rows=[('Records – PubMed',426),('Records – Scopus',699),('Records – Web of Science',744 if False else 532),('Total identified','=SUM(B3:B5)'),('Duplicates removed','=B6-B8'),("Records screened","=COUNTA(Screening!A:A)-1"),('Excluded at title/abstract','=COUNTIF(Screening!I:I,"Exclude*")'),('  of which umbrella reviews/overviews (kept for citation check)','=COUNTIF(Screening!I:I,"Exclude – umbrella*")'),('Reports sought for retrieval','=B8-B9'),('  likely include (paediatric SR/MA)','=COUNTIF(Screening!I:I,"Include*")'),('  check for separate paediatric estimate','=COUNTIF(Screening!I:I,"Full text*")')]
for j,(a,b) in enumerate(rows,start=3):
    p.cell(row=j,column=1,value=a).font=base; c=p.cell(row=j,column=2,value=b); c.font=blue if isinstance(b,int) else base
p.column_dimensions['A'].width=60; p.column_dimensions['B'].width=10
sc=wb.create_sheet('Screening'); sc.append(list(S.columns))
for x in sc[1]: x.font=hdr; x.fill=hf
for r in S.itertuples(index=False): sc.append([str(v) for v in r])
for row in sc.iter_rows(min_row=2):
    for x in row: x.font=base
    d=row[8].value
    if d!='Exclude':
        f=G if d.startswith('Include') else Y if d.startswith('Full') else B
        for x in row[:11]: x.fill=f
for j,w in enumerate([6,60,28,6,28,26,10,18,30,50,18,80],1): sc.column_dimensions[get_column_letter(j)].width=w
sc.freeze_panes='C2'; sc.auto_filter.ref=sc.dimensions
wb.save('outputs/umbrella_review_screening.xlsx')
